#include <stdio.h>

// Function to perform addition
void sum()
{
    float sum_1, sum_2, sum_result;

    // Input first number
    printf("PLEASE ENTER THE FIRST NUMBER \n");
    scanf("%f", &sum_1);

    // Input second number
    printf("PLEASE ENTER THE SECOND NUMBER \n");
    scanf("%f", &sum_2);

    // Perform addition and display result
    sum_result = sum_1 + sum_2;
    printf("%.4f + %.4f = %.4f \n", sum_1, sum_2, sum_result);
    printf("________________________________________\n");
    printf("TRANSACTIONS YOU CAN DO: \n");
}

// Function to perform subtraction
void subtraction()
{
    float subtraction_1, subtraction_2, subtraction_result;

    // Input first number
    printf("PLEASE ENTER THE FIRST NUMBER \n");
    scanf("%f", &subtraction_1);

    // Input second number
    printf("PLEASE ENTER THE SECOND NUMBER \n");
    scanf("%f", &subtraction_2);

    // Perform subtraction and display result
    subtraction_result = subtraction_1 - subtraction_2;
    printf("%.4f - %.4f = %.4f \n", subtraction_1, subtraction_2, subtraction_result);
    printf("________________________________________\n");
    printf("TRANSACTIONS YOU CAN DO: \n");
}

// Function to perform multiplication
void multiplication()
{
    float multiplication_1, multiplication_2, multiplication_result;

    // Input first number
    printf("PLEASE ENTER THE FIRST NUMBER \n");
    scanf("%f", &multiplication_1);

    // Input second number
    printf("PLEASE ENTER THE SECOND NUMBER \n");
    scanf("%f", &multiplication_2);

    // Perform multiplication and display result
    multiplication_result = multiplication_1 * multiplication_2;
    printf("%.4f * %.4f = %.4f \n", multiplication_1, multiplication_2, multiplication_result);
    printf("________________________________________\n");
    printf("TRANSACTIONS YOU CAN DO: \n");
}

// Function to perform division
void division()
{
    float division_1, division_2, division_result;

    // Input first number
    printf("PLEASE ENTER THE FIRST NUMBER \n");
    scanf("%f", &division_1);

    // Input second number
    printf("PLEASE ENTER THE SECOND NUMBER \n");
    scanf("%f", &division_2);

    // Check if denominator is not zero
    if (division_2 != 0)
    {
        // Perform division and display result
        division_result = division_1 / division_2;
        printf("%.4f / %.4f = %.4f \n", division_1, division_2, division_result);
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
    }
    else
    {
        printf("ERROR, DENOMINATOR CAN'T BE ZERO! \n");
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
        return;
    }
}

// Function to calculate power
void power()
{
    float power_result = 1;
    float power_base;
    int power_exponent;

    // Input base number
    printf("PLEASE ENTER THE BASE NUMBER\n");
    scanf("%f", &power_base);

    // Check if base is zero
    if (power_base == 0)
    {
        // Input exponent number
        printf("PLEASE ENTER THE EXPONENT NUMBER\n");
        if (scanf("%d", &power_exponent) == 1)
        {
            // Handle special cases for zero base
            if (power_exponent == 0)
            {
                printf("0^0 IS UNCERTAIN\n");
                printf("________________________________________\n");
        		printf("TRANSACTIONS YOU CAN DO: \n");
            }
            else if (power_exponent >= 0)
            {
                printf("0^%d = 0\n", power_exponent);
                printf("________________________________________\n");
        		printf("TRANSACTIONS YOU CAN DO: \n");
            }
            else if (power_exponent < 0)
            {
                printf("0^%d IS UNDEFINED\n", power_exponent);
                printf("________________________________________\n");
        		printf("TRANSACTIONS YOU CAN DO: \n");
            }
        }
        else
        {
            printf("THE EXPONENT OF THE NUMBER MUST BE AN INTEGER VALUE\n");
            return;
        }
    }
    else if (power_base != 0)
    {
        // Input exponent number
        printf("PLEASE ENTER THE EXPONENT NUMBER\n");
        if (scanf("%d", &power_exponent) == 1)
        {
            // Handle cases for non-zero base
            if (power_exponent == 0)
            {
                printf("%.4f^0 = 1\n", power_base);
            }
            else if (power_exponent > 0)
            {
                // Calculate positive exponent
                for (int i = power_exponent; i >= 1; i--)
                {
                    power_result *= power_base;
                }
                printf("%.4f^%d = %.4f\n", power_base, power_exponent, power_result);
                printf("________________________________________\n");
                printf("TRANSACTIONS YOU CAN DO: \n");
            }
            else if (power_exponent < 0)
            {
                // Calculate negative exponent
                power_exponent = -power_exponent;
                for (int i = power_exponent; i >= 1; i--)
                {
                    power_result /= power_base;
                }
                printf("%.4f^-%d = %.4f\n", power_base, power_exponent, power_result);
                printf("________________________________________\n");
                printf("TRANSACTIONS YOU CAN DO: \n");
            }
        }
        else
        {
            printf("THE EXPONENT OF THE NUMBER MUST BE AN INTEGER VALUE\n");
            return;
        }
    }
}

// Function to calculate the average of numbers inputted
void average()
{
    float average_total_entered = 0;
    int average_counter = 0;
    float average_number;
    float average_average;
    char average_character;

    // Loop to input numbers until '*' is entered
    while (1)
    {
        printf("PLEASE ENTER A NUMBER (ENTER \"*\" TO END):\n");
        if (scanf("%f", &average_number) == 1)
        {
            average_total_entered += average_number;
            average_counter++;
        }
        else
        {
            scanf("%c", &average_character);
            if (average_character == '*')
            {
                break;
            }
            else
            {
                printf("INVALID VALUE PLEASE ENTER A NUMBER OR \"*\"\n");
            }
        }
    }

    // Check if any number is entered
    if (average_counter == 0)
    {
        printf("NO NUMBER HAS BEEN ENTERED AND THE AVERAGE CANNOT BE CALCULATED.\n");
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
    }
    else
    {
        // Calculate and display the average
        float average_average = average_total_entered / average_counter;
        printf("AVERAGE OF ENTERED NUMBERS: %.4f\n", average_average);
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
    }
}

// Function to find the maximum of numbers inputted
void maximum()
{
    float maximum_enter;
    float maximum_maximum = -9000000000000000000;
    float maximum_counter = 0;
    char maximum_character;

    // Loop to input numbers until '*' is entered
    while (1)
    {
        printf("PLEASE ENTER A NUMBER OR \"*\"\n");
        if (scanf("%f", &maximum_enter) == 1)
        {
            maximum_counter++;
            if (maximum_enter > maximum_maximum)
            {
                maximum_maximum = maximum_enter;
            }
        }
        else
        {
            scanf("%c", &maximum_character);
            if (maximum_character == '*')
            {
                break;
            }
            else
            {
                printf("INVALID VALUE PLEASE ENTER A NUMBER OR \"*\".\n");
            }
        }
    }

    // Check if any number is entered
    if (maximum_counter == 0)
    {
        printf("NO NUMBER HAS BEEN ENTERED\n");
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
    }
    else
    {
        // Display the maximum value
        printf("MAXIMUM VALUE IS %f\n", maximum_maximum);
        printf("________________________________________\n");
        printf("TRANSACTIONS YOU CAN DO: \n");
    }
}

// Function for the main menu loop
void menu_loop()
{
    while (1)
    {
        float menu = -1;
        // Display the menu options
        printf("(1) ADD TWO NUMBERS \n");
        printf("(2) SUBTRACT TWO NUMBERS \n");
        printf("(3) MULTIPLY TWO NUMBERS \n");
        printf("(4) DIVIDE TWO NUMBERS \n");
        printf("(5) TAKE THE NTH POWER OF A NUMBER \n");
        printf("(6) FIND AVERAGE OF NUMBERS INPUTTED \n");
        printf("(7) FIND THE MAXIMUM OF NUMBERS INPUTTED \n");
        printf("(0) EXIT \n");
        printf("PLEASE SELECT: \n");
        scanf("%f", &menu);

        // Perform the selected operation
        if (menu == 1)
        {
            sum();
        }
        else if (menu == 2)
        {
            subtraction();
        }
        else if (menu == 3)
        {
            multiplication();
        }
        else if (menu == 4)
        {
            division();
        }
        else if (menu == 5)
        {
            power();
        }
        else if (menu == 6)
        {
            average();
        }
        else if (menu == 7)
        {
            maximum();
        }
        else if (menu == 0)
        {
            // Exit the program
            printf("________________________________________\n");
            printf("!! PROGRAM TERMINATED !! \n");
            return;
        }
        else
        {
            // Invalid input
            printf("PLEASE ENTER A VALID VALUE\n");
            printf("________________________________________\n");
            printf("TRANSACTIONS YOU CAN DO: \n");
        }
    }
}

// Main function
int main()
{
    // Display welcome message
    printf("%%%% WELCOME TO GTU CALCULATOR MACHINE  %%%% \n");
    printf("%%%% STUDENT NAME: MEHMET AKIF PEKSEN   %%%% \n");
    printf("%%%% PLEASE SELECT FROM THE FOLLOWING   %%%% \n");
    printf("%%%% MENU :                             %%%% \n");

    // Start the main menu loop
    menu_loop();

    return 0;
}

