#include <stdio.h>

int find_size_of_array(int A[]){
	int temp, index = 0;
	do{
	temp = A[index];
	index++;
	}while(temp != -1);
		
	return index;
}

int print_histogram(int A[], int a, int b, int size, int restart){
	int counter, maximum = 0, i, j, column;
	for(i=a;i<=b;i++){
		counter = 0;
		for(j=0;j<size;j++){
			if(A[j] == i) counter++;			
		}
		if(counter >= maximum) maximum = counter;
	}
	for(column=maximum;column>0;column--){
		for(i=a;i<=b;i++){
			counter = 0;
			for(j=0;j<size;j++){
				if(A[j] == i) counter++;
			}
			if(counter >= column) printf("*");
			else printf(" ");
		}
		printf("\n");
	}
	if(restart == 1) return 0;
	else{
		printf("Would you like to add new numbers? (press 1 for yes, press 0 for no): ");
		scanf("%d",&restart);
		return restart;
	}			
	
}

int add_new_numbers(int A[], int size){
	int number;
	do{
		scanf("%d",&number);
		if(number != -1){
			A[size-1] = number;
			size++;
			A[size-1] = -1;
		}
	}while(number != -1);
	return size;
}

void print_average(int A[], int size, int a, int b){
	int i, j, sum = 0, counter = 0;
	for(i=a;i<=b;i++){			
			for(j=0;j<size;j++){
				if(A[j] == i){ 
				counter++;
				sum += i;
				}		
			}
		}
	printf("Average: %.2f\n",((float)sum/counter));	
}

void print_median(int A[], int size, int a, int b){
	int counter = 0, check = 0, temp, flag = 0, i, j;
	for(i=a;i<=b;i++){
		for(j=0;j<size;j++){
			if(A[j] == i) counter++;			
		}
	}
	for(i=a;i<=b;i++){
		for(j=0;j<size;j++){
			if(A[j] == i) check++;
			if(counter % 2 == 0 && check == counter/2 && flag == 0){
				temp = i;
				flag = 1;
			}	
			else if(counter % 2 == 0 && check == (counter/2)+1 && flag == 1){
				printf("Median: %.2f\n",(float)(i+temp)/2);
				flag = 2;
				break;
			}		
			else if(counter % 2 != 0 && check == (counter+1)/2){
				printf("Median: %.2f\n",(float)i);
				flag = 2;
				break;
			} 
		}
		if(flag == 2) break;		
	}
}

void print_mode(int A[], int size, int a, int b){
	int maximum = 0, counter, i, j;
	for(i=a;i<=b;i++){
		counter = 0;
		for(j=0;j<size;j++){
			if(A[j] == i) counter++;			
		}
		if(counter >= maximum) maximum = counter;
	}
	printf("Mode: ");
	for(i=b;i>=a;i--){
		counter = 0;
		for(j=0;j<size;j++){
			if(A[j] == i) counter++;
			}
		if(counter == maximum) printf("%d ",i);	
	}		
	printf("\n");
}
int main(){
	
	int size, value_A, value_B, restart = 0, i;
	
	int number_array[250] = {91, 127, 65, 143, 77, 184, 159, 104, 50, 200, 65, 176, 155, 98, 163, 189, 166, 105, 77, 87, 151, 84, 158, 116, 170, 129, 85, 161, 95, 135, 75, 107, 131, 52, 150, 170, 190, 145, 119, 95, 179, 71, 191, 174, 95, 154, 115, 172, 74, 91, 124, 108, 56, 184, 153, 118, 123, 127, 99, 64, 55, 170, 53, 162, 110, 178, 141, 173, 100, 106, 195, 53, 53, 140, 175, 53, 59, 108, 62, 82, 192, 92, 165, 171, 154, 176, 150, 147, 93, 134, 97, 152, 82, 91, 59, 61, 143, 92, 153, 144, 104, 98, 91, 195, 67, 94, 144, 157, 179, 68, 160, 131, 102, 158, 190, 105, 123, 180, -1};

	
	size = find_size_of_array(number_array);
	
	printf("Enter A and B values: ");
	scanf("%d %d",&value_A ,&value_B);
	restart = print_histogram(number_array,value_A,value_B,size,restart);
	if(restart == 1){ 
		size = add_new_numbers(number_array,size);
		print_histogram(number_array,value_A,value_B,size,restart);
	}
	print_average(number_array,size,value_A,value_B);	
	print_median(number_array,size,value_A,value_B);
	print_mode(number_array,size,value_A,value_B);
	
	return 0;	
}
