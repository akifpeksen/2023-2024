#include <stdio.h>

int main()
{
    int menu, i, x, y, class, minimum_x_class_0 = 999, minimum_y_class_0 = 999, minimum_x_class_1 = 999, minimum_y_class_1 = 999;
    int maximum_x_class_0 = -999, maximum_y_class_0 = -999, maximum_x_class_1 = -999, maximum_y_class_1 = -999;
    int maximum_x, maximum_y, minimum_x, minimum_y, pivot_x, pivot_y, last_pivot_x, last_pivot_y, error, minimum_error = 999;
    int r1, r2, r3, r4, last_i, success;

    FILE *data;
    FILE *test1;
    FILE *test_final;

    do
    {
        printf("1. Explore Data\n");
        printf("2. Train Model\n");
        printf("3. Test Model\n");
        printf("4. Exit\n");
        printf("Choice:");
        scanf("%d", &menu);
        /* Menu */
        switch (menu)
        {

        case 1:

            data = fopen("data.txt", "r");

            while (fscanf(data, "%d %d %d", &x, &y, &class) != EOF)
            {
                /* Determining the maximum and minimum x, y values of each class */
                if (class == 0)
                {

                    if (x > maximum_x_class_0)
                    {
                        maximum_x_class_0 = x;
                    }
                    if (x < minimum_x_class_0)
                    {
                        minimum_x_class_0 = x;
                    }
                    if (y > maximum_y_class_0)
                    {
                        maximum_y_class_0 = y;
                    }
                    if (y < minimum_y_class_0)
                    {
                        minimum_y_class_0 = y;
                    }
                }

                if (class == 1)
                {

                    if (x > maximum_x_class_1)
                    {
                        maximum_x_class_1 = x;
                    }
                    if (x < minimum_x_class_1)
                    {
                        minimum_x_class_1 = x;
                    }
                    if (y > maximum_y_class_1)
                    {
                        maximum_y_class_1 = y;
                    }
                    if (y < minimum_y_class_1)
                    {
                        minimum_y_class_1 = y;
                    }
                }
            }
            /* Outputs */
            printf("Minimum and Maximum X and Y values:\n");
            printf("Class 0: X in [%d,%d], Y in [%d,%d]\n", minimum_x_class_0, maximum_x_class_0, minimum_y_class_0, maximum_y_class_0);
            printf("Class 1: X in [%d,%d], Y in [%d,%d]\n", minimum_x_class_1, maximum_x_class_1, minimum_y_class_1, maximum_y_class_1);

            fclose(data);

            break;

        case 2:
            /* Determining the largest and smallest x, y values independent of classes (max, min range will be checked when determining the separator) */
            if (maximum_x_class_1 >= maximum_x_class_0)
            {
                maximum_x = maximum_x_class_1;
            }
            else
            {
                maximum_x = maximum_x_class_0;
            }

            if (maximum_y_class_1 >= maximum_y_class_0)
            {
                maximum_y = maximum_y_class_1;
            }
            else
            {
                maximum_y = maximum_y_class_0;
            }

            if (minimum_x_class_1 <= minimum_x_class_0)
            {
                minimum_x = minimum_x_class_1;
            }
            else
            {
                minimum_x = minimum_x_class_0;
            }

            if (minimum_y_class_1 <= minimum_y_class_0)
            {
                minimum_y = minimum_y_class_1;
            }
            else
            {
                minimum_y = minimum_y_class_0;
            }

            for (i = 0; i < 16; i++)
            {

                switch (i)
                {
                /* Trying all combinations for Regions */
                case 1: r1 = 0; r2 = 0; r3 = 0; r4 = 0; break;
                case 2: r1 = 1; r2 = 0; r3 = 0; r4 = 0; break;
                case 3: r1 = 0; r2 = 1; r3 = 0; r4 = 0; break;
                case 4: r1 = 1; r2 = 1; r3 = 0; r4 = 0; break;
                case 5: r1 = 0; r2 = 0; r3 = 1; r4 = 0; break;
                case 6: r1 = 1; r2 = 0; r3 = 1; r4 = 0; break;
                case 7: r1 = 0; r2 = 1; r3 = 1; r4 = 0; break;
                case 8: r1 = 1; r2 = 1; r3 = 1; r4 = 0; break;
                case 9: r1 = 0; r2 = 0; r3 = 0; r4 = 1; break;
                case 10: r1 = 1; r2 = 0; r3 = 0; r4 = 1; break;
                case 11: r1 = 0; r2 = 1; r3 = 0; r4 = 1; break;
                case 12: r1 = 1; r2 = 1; r3 = 0; r4 = 1; break;
                case 13: r1 = 0; r2 = 0; r3 = 1; r4 = 1; break;
                case 14: r1 = 1; r2 = 0; r3 = 1; r4 = 1; break;
                case 15: r1 = 0; r2 = 1; r3 = 1; r4 = 1; break;
                case 16: r1 = 1; r2 = 1; r3 = 1; r4 = 1; break;

                }
                /* Checking all points between the maximum and minimum x, y values and determining the best separator point */
                for (pivot_x = maximum_x; pivot_x >= minimum_x; pivot_x--)
                {

                    for (pivot_y = maximum_y; pivot_y >= minimum_y; pivot_y--)
                    {

                        error = 0;
                        data = fopen("data.txt", "r");

                        while (fscanf(data, "%d %d %d", &x, &y, &class) != EOF)
                        {
                            /* Increasing the error counter if the class of the point is not the same as the region it is in */
                            if (x <= pivot_x && y <= pivot_y)
                            {
                                if (class != r3)
                                    error++;
                            }
                            else if (x <= pivot_x && y > pivot_y)
                            {
                                if (class != r1)
                                    error++;
                            }
                            else if (x > pivot_x && y <= pivot_y)
                            {
                                if (class != r4)
                                    error++;
                            }
                            else if (x > pivot_x && y > pivot_y)
                            {
                                if (class != r2)
                                    error++;
                            }
                        }
                        fclose(data);
                        /* updating the state with the fewest errors as the best state */
                        if (error < minimum_error)
                        {
                            minimum_error = error;
                            last_i = i;
                            last_pivot_x = pivot_x;
                            last_pivot_y = pivot_y;
                        }
                    }
                }
            }

            /* Equalization of Region values to the values in the best case */
            switch (last_i)
            {
            case 1: r1 = 0; r2 = 0; r3 = 0; r4 = 0; break;
            case 2: r1 = 1; r2 = 0; r3 = 0; r4 = 0; break;
            case 3: r1 = 0; r2 = 1; r3 = 0; r4 = 0; break;
            case 4: r1 = 1; r2 = 1; r3 = 0; r4 = 0; break;
            case 5: r1 = 0; r2 = 0; r3 = 1; r4 = 0; break;
            case 6: r1 = 1; r2 = 0; r3 = 1; r4 = 0; break;
            case 7: r1 = 0; r2 = 1; r3 = 1; r4 = 0; break;
            case 8: r1 = 1; r2 = 1; r3 = 1; r4 = 0; break;
            case 9: r1 = 0; r2 = 0; r3 = 0; r4 = 1; break;
            case 10: r1 = 1; r2 = 0; r3 = 0; r4 = 1; break;
            case 11: r1 = 0; r2 = 1; r3 = 0; r4 = 1; break;
            case 12: r1 = 1; r2 = 1; r3 = 0; r4 = 1; break;
            case 13: r1 = 0; r2 = 0; r3 = 1; r4 = 1; break;
            case 14: r1 = 1; r2 = 0; r3 = 1; r4 = 1; break;
            case 15: r1 = 0; r2 = 1; r3 = 1; r4 = 1; break;
            case 16: r1 = 1; r2 = 1; r3 = 1; r4 = 1; break;
            }

            /* Outputs */
            printf("Seperator coordinates X = %d, Y = %d\n", last_pivot_x, last_pivot_y);
            printf("Training Error of the model = %d\n",minimum_error);
            printf("Labels of the regions: R1 = %d, R2 = %d, R3 = %d, R4 = %d,\n", r1, r2, r3, r4);

            break;

        case 3:

            test1 = fopen("test 1.txt", "r");
            error = 0;
            success = 0;
            while (fscanf(test1, "%d %d %d", &x, &y, &class) != EOF)
            {
                /* If the points read from the file have the same class as the region they are in according to their coordinates,
                the success counter is incremented, otherwise the error counter is incremented. */
                if (x <= last_pivot_x && y <= last_pivot_y)
                {
                    if (class == r3)
                    {
                        success++;
                    }
                    else
                    {
                        error++;
                    }
                }
                else if (x <= last_pivot_x && y > last_pivot_y)
                {
                    if (class == r1)
                    {
                        success++;
                        ;
                    }
                    else
                    {
                        error++;
                    }
                }
                else if (x > last_pivot_x && y <= last_pivot_y)
                {
                    if (class == r4)
                    {
                        success++;
                    }
                    else
                    {
                        error++;
                    }
                }
                else if (x > last_pivot_x && y > last_pivot_y)
                {
                    if (class == r2)
                    {
                        success++;
                    }
                    else
                    {
                        error++;
                    }
                }
            }
            /* Outputs */
            printf("Success: %d ", success);
            printf("Unsuccess: %d\n", error);
            printf("Success rate = %.2f\n", 100 * ((float)success / (float)(success + error)));
            fclose(test1);

            test_final = fopen("test-final.txt", "r");
            while (fscanf(test1, "%d %d", &x, &y) != EOF)
            {
                /* The points read from the file are expected to be equal to the class value of the region in which they are located */
                if (x <= last_pivot_x && y <= last_pivot_y)
                {
                    printf("x:%2d y:%2d predicted label:%d \n", x, y, r3);
                }
                else if (x <= last_pivot_x && y > last_pivot_y)
                {
                    printf("x:%2d y:%2d predicted label:%d \n", x, y, r1);
                }
                else if (x > last_pivot_x && y <= last_pivot_y)
                {
                    printf("x:%2d y:%2d predicted label:%d \n", x, y, r4);
                }
                else if (x > last_pivot_x && y > last_pivot_y)
                {
                    printf("x:%2d y:%2d predicted label:%d \n", x, y, r2);
                }
            }
            fclose(test_final);

            break;
        case 4:
            printf("Bye Bye!\n");
            break;
        default:
            printf("Please enter a valid value!\n");
            break;
        }
    } while (menu != 4);

    return 0;
}
