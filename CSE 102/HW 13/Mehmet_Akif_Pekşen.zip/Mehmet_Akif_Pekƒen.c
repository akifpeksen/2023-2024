#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_SIZE 25

typedef struct Data{
	int flag;
	char class[MAX_SIZE];
	char order[MAX_SIZE];
	char family[MAX_SIZE];
	char genus[MAX_SIZE];
	char species[MAX_SIZE];	
	struct Data *next;
}Data;

Data *add_data(Data *current){

	char input[MAX_SIZE];
	printf("Enter species information:\n");	
	printf("Class: ");
	scanf(" %[^\n]",input);	
	strcpy(current->class,input);	
	printf("Order: ");
	scanf(" %[^\n]",input);
	strcpy(current->order,input);	
	printf("Family: ");	
	scanf(" %[^\n]",input);
	strcpy(current->family,input);
	printf("Genus: ");
	scanf(" %[^\n]",input);		
	strcpy(current->genus,input);
	printf("Species: ");	
	scanf(" %[^\n]",input);
	strcpy(current->species,input);	
	current->flag = 1;
	Data *another = (Data*)malloc(sizeof(Data));
	current->next = another;
	another->flag = 0;
	return another;

}

void update_data(Data *current){
	
	char input[MAX_SIZE];
	printf("Enter species information to modify:\n");
	printf("Old Species: ");
	scanf(" %[^\n]",input);	
	
	while(current->next!=NULL){
		if(strcmp(current->species,input) == 0){
			printf("New Class: ");
			scanf(" %[^\n]",input);	
			strcpy(current->class,input);
			printf("New Order: ");
			scanf(" %[^\n]",input);	
			strcpy(current->order,input);
			printf("New Family: ");
			scanf(" %[^\n]",input);	
			strcpy(current->family,input);
			printf("New Genus: ");
			scanf(" %[^\n]",input);	
			strcpy(current->genus,input);
			printf("New Species: ");
			scanf(" %[^\n]",input);	
			strcpy(current->species,input);
			return;
		}	
		current = current->next;
	}
	printf("NO MATCH!\n");

}

Data* delete_data(Data *current){
	
	if(current->next == NULL){
		printf("EMPTY!!\n");
		return current;	
	}	 
	char input[MAX_SIZE];
	Data *first = current;
	printf("Enter species information to delete:\n");
	printf("Species: ");
	scanf(" %[^\n]",input);	
	if(strcmp(current->species,input) == 0){ 
		free(current);
		return current->next;	
	}	
	do{	
		if(strcmp(current->next->species,input) == 0){			
			free(current->next);
			current->next =	current->next->next;			
			return first;
		}
		current = current->next;
	}while(current->next!=NULL);
	printf("NO MATCH!\n");

}

void print_data(Data *current){
	
	printf("\n");
	while(current->next != NULL){
		printf("Class: %s\n",current->class);
		printf("Order: %s\n",current->order);
		printf("Family: %s\n",current->family);
		printf("Genus: %s\n",current->genus);
		printf("Species: %s\n\n",current->species);
		current = current->next;
	}
	
}

void list_data(Data *current){
	Data *first;
	first = current;
	char criteria[MAX_SIZE];
	char temp[MAX_SIZE];
	int i, k, size = 0;
	printf("Enter list criteria (class, order, family, genus, species): ");
	scanf(" %[^\n]",criteria);	
	while(current != NULL){
		size++;
		current=current->next;
	}
	if(strcmp(criteria,"class")==0){
		for(i=0;i<size;i++){	
		current=first;
			for(k=0;k<size;k++){
				if(current->next==NULL) break;	
				if(strcmp(current->class,current->next->class) > 0 && current->flag == 1 && current->next->flag == 1){
					strcpy(temp,current->class);
					strcpy(current->class,current->next->class);
					strcpy(current->next->class,temp);
							
					strcpy(temp,current->order);
					strcpy(current->order,current->next->order);
					strcpy(current->next->order,temp);
								
					strcpy(temp,current->family);
					strcpy(current->family,current->next->family);
					strcpy(current->next->family,temp);
								
					strcpy(temp,current->genus);
					strcpy(current->genus,current->next->genus);
					strcpy(current->next->genus,temp);
							
					strcpy(temp,current->species);
					strcpy(current->species,current->next->species);
					strcpy(current->next->species,temp);									
				}				
				current = current->next;
			}	
		}
	}
	if(strcmp(criteria,"order")==0){
		for(i=0;i<size;i++){	
		current=first;
			for(k=0;k<size;k++){
				if(current->next==NULL) break;	
				if(strcmp(current->class,current->next->class) > 0 && current->flag == 1 && current->next->flag == 1){
					strcpy(temp,current->class);
					strcpy(current->class,current->next->class);
					strcpy(current->next->class,temp);
							
					strcpy(temp,current->order);
					strcpy(current->order,current->next->order);
					strcpy(current->next->order,temp);
								
					strcpy(temp,current->family);
					strcpy(current->family,current->next->family);
					strcpy(current->next->family,temp);
								
					strcpy(temp,current->genus);
					strcpy(current->genus,current->next->genus);
					strcpy(current->next->genus,temp);
							
					strcpy(temp,current->species);
					strcpy(current->species,current->next->species);
					strcpy(current->next->species,temp);									
				}				
				current = current->next;
			}	
		}
	}	
	if(strcmp(criteria,"family")==0){
		for(i=0;i<size;i++){	
		current=first;
			for(k=0;k<size;k++){
				if(current->next==NULL) break;	
				if(strcmp(current->family,current->next->family) > 0 && current->flag == 1 && current->next->flag == 1){
					strcpy(temp,current->class);
					strcpy(current->class,current->next->class);
					strcpy(current->next->class,temp);
							
					strcpy(temp,current->order);
					strcpy(current->order,current->next->order);
					strcpy(current->next->order,temp);
								
					strcpy(temp,current->family);
					strcpy(current->family,current->next->family);
					strcpy(current->next->family,temp);
								
					strcpy(temp,current->genus);
					strcpy(current->genus,current->next->genus);
					strcpy(current->next->genus,temp);
							
					strcpy(temp,current->species);
					strcpy(current->species,current->next->species);
					strcpy(current->next->species,temp);									
				}				
				current = current->next;
			}	
		}
	}	
	if(strcmp(criteria,"genus")==0){
		for(i=0;i<size;i++){	
		current=first;
			for(k=0;k<size;k++){
				if(current->next==NULL) break;	
				if(strcmp(current->genus,current->next->genus) > 0 && current->flag == 1 && current->next->flag == 1){
					strcpy(temp,current->class);
					strcpy(current->class,current->next->class);
					strcpy(current->next->class,temp);
							
					strcpy(temp,current->order);
					strcpy(current->order,current->next->order);
					strcpy(current->next->order,temp);
								
					strcpy(temp,current->family);
					strcpy(current->family,current->next->family);
					strcpy(current->next->family,temp);
								
					strcpy(temp,current->genus);
					strcpy(current->genus,current->next->genus);
					strcpy(current->next->genus,temp);
							
					strcpy(temp,current->species);
					strcpy(current->species,current->next->species);
					strcpy(current->next->species,temp);									
				}				
				current = current->next;
			}	
		}
	}	
	if(strcmp(criteria,"species")==0){
		for(i=0;i<size;i++){	
		current=first;
			for(k=0;k<size;k++){
				if(current->next==NULL) break;	
				if(strcmp(current->species,current->next->species) > 0 && current->flag == 1 && current->next->flag == 1){
					strcpy(temp,current->class);
					strcpy(current->class,current->next->class);
					strcpy(current->next->class,temp);
							
					strcpy(temp,current->order);
					strcpy(current->order,current->next->order);
					strcpy(current->next->order,temp);
								
					strcpy(temp,current->family);
					strcpy(current->family,current->next->family);
					strcpy(current->next->family,temp);
								
					strcpy(temp,current->genus);
					strcpy(current->genus,current->next->genus);
					strcpy(current->next->genus,temp);
							
					strcpy(temp,current->species);
					strcpy(current->species,current->next->species);
					strcpy(current->next->species,temp);									
				}				
				current = current->next;
			}	
		}
	}		
}

void free_data(Data *current){
	
	if(current!=NULL) free_data(current->next);
	free(current);

}

void main(){

	Data *myData = (Data*)malloc(sizeof(Data));
	Data *current = myData;
 	int choice;
 	do{
 	printf("0.ADD\n");
 	printf("1.UPDATE\n");
 	printf("2.DELETE\n");
 	printf("3.PRINT\n");
 	printf("4.LIST\n");
 	printf("5.EXIT\n");
 	printf("CHOICE: ");
 	scanf("%d",&choice);
 	switch(choice){
 		case 0:
 		current = add_data(current);
 			break;
 		case 1:
 		update_data(myData);
 			break;
 		case 2:
 		myData = delete_data(myData);
 			break;
 		case 3:
 		print_data(myData);
 			break;
 		case 4:
 		list_data(myData);
 		printf("\nListed species:\n");
 		print_data(myData);
 			break;
 		case 5:
 		free_data(myData);
 		printf("BYE BYE!\n");
 			break;
 		default:
 		printf("INVALID VALUE!\n");					
 	}
 	
 	}while(choice != 5);


}
