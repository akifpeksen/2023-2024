#include <stdio.h>

char first_initial(FILE *id_fp, int id){    
	int element1;
	char element2, temp;
    while(fscanf(id_fp,"%d;%c", &element1, &element2) != EOF){
   	  	
   	while((temp = fgetc(id_fp)) != '\n'){
   	
   	}	
   	if(element1 == id) return element2;

	}
}
void initial_pass_or_fail(FILE *info_fp, char initial){
		
		FILE *second;
		int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, student_counter108 = 0, student_counter102 = 0;
    	int read_id, read_mt, read_final, read_course_id;
    	double average_mt108, average_mt102, average_final108, average_final102; 
    	double sum_mt108=0, sum_final108=0, sum_mt102=0, sum_final102=0;
    	double student_mt_gpa, student_final_gpa, student_average_gpa;
    	char check;
    	
    	while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){  	
    	if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		
    		if(read_course_id == 108){
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    		
    		if(read_course_id == 108)
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}	
    		
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;    	
		}
		
				
		average_mt108 = (sum_mt108 / student_counter108);
		average_final108 = (sum_final108 / student_counter108);
		average_mt102 = (sum_mt102 / student_counter102);
		average_final102 = (sum_final102 / student_counter102);
		
		fclose(info_fp);
		
		
		info_fp = fopen("first 1.txt","r");
		while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){
		if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		   		
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    	}	
  		

  		if(read_course_id == 108){		
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > 40 && read_mt > average_mt108) student_mt_gpa = 3.50;	
			else if(read_mt < 40 && read_mt > average_mt108) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt108) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt108) student_mt_gpa = 1.00;				
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final108) student_final_gpa = 3.50;	
			else if(read_final > 40 && read_final > average_final108) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final108) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final108) student_final_gpa = 1.00;
		}
		else if(read_course_id == 102){
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > average_mt102) student_mt_gpa = 3.50;	
			else if(read_mt > 40 && read_mt > average_mt102) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt102) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt102) student_mt_gpa = 1.00;
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final102) student_final_gpa = 3.50;	
			else if(read_final < 40 && read_final > average_final102) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final102) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final102) student_final_gpa = 1.00;
		}
		
		student_average_gpa = (student_final_gpa + student_mt_gpa) / 2;
		
		second = fopen("second 1.txt","r"); 
		check = first_initial(second,read_id);
		fclose(second);
		
		if(initial == check){
			
			if(student_average_gpa < 1.75) printf("ID:%d Class: %d Letter Grade: F (FAIL) \n",read_id,read_course_id);
			else if(student_average_gpa < 2.75) printf("ID:%d Class: %d Letter Grade: D (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.25) printf("ID:%d Class: %d Letter Grade: C (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.75) printf("ID:%d Class: %d Letter Grade: B (PASS) \n",read_id,read_course_id);
    		else printf("ID:%d Class: %d Letter Grade: A (PASS) \n",read_id,read_course_id);
    		
    	}		
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;   		
		}

}

double average_grade(FILE *info_fp, int id){
  
    	int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, student_counter108 = 0, student_counter102 = 0;
    	int read_id, read_mt, read_final, read_course_id, student_course_id, match = 0; 
    	double average_mt108, average_mt102, average_final108, average_final102; 
    	double sum_mt108=0, sum_final108=0, sum_mt102=0, sum_final102=0;
    	double student_mt_gpa, student_final_gpa, student_average_gpa, student_mt, student_final;
    	while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){
   	
    	if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		
    		if(read_course_id == 108){
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    		
    		if(read_course_id == 108)
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}	
    	
    	if(id == read_id){
    		student_mt = read_mt;
    		student_final = read_final; 
    		student_course_id = read_course_id;  
    		match = 1;	
    	}
    	  	
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;    	
		}
		
				
		average_mt108 = (sum_mt108 / student_counter108);
		average_final108 = (sum_final108 / student_counter108);
		average_mt102 = (sum_mt102 / student_counter102);
		average_final102 = (sum_final102 / student_counter102);
		
		if(student_course_id == 108){		
			if(student_mt > 90) student_mt_gpa = 4.00;
			else if(student_mt > 40 && student_mt > average_mt108) student_mt_gpa = 3.50;	
			else if(student_mt < 40 && student_mt > average_mt108) student_mt_gpa = 3.00;
			else if(student_mt > 40 && student_mt < average_mt108) student_mt_gpa = 2.50;
			else if(student_mt < 40 && student_mt < average_mt108) student_mt_gpa = 1.00;				
			
			if(student_final > 90) student_final_gpa = 4.00;
			else if(student_final > average_final108) student_final_gpa = 3.50;	
			else if(student_final > 40 && student_final > average_final108) student_final_gpa = 3.00;
			else if(student_final > 40 && student_final < average_final108) student_final_gpa = 2.50;
			else if(student_final < 40 && student_final < average_final108) student_final_gpa = 1.00;
		}
		else if(student_course_id == 102){
			if(student_mt > 90) student_mt_gpa = 4.00;
			else if(student_mt > average_mt102) student_mt_gpa = 3.50;	
			else if(student_mt > 40 && student_mt > average_mt102) student_mt_gpa = 3.00;
			else if(student_mt > 40 && student_mt < average_mt102) student_mt_gpa = 2.50;
			else if(student_mt < 40 && student_mt < average_mt102) student_mt_gpa = 1.00;
			
			if(student_final > 90) student_final_gpa = 4.00;
			else if(student_final > average_final102) student_final_gpa = 3.50;	
			else if(student_final < 40 && student_final > average_final102) student_final_gpa = 3.00;
			else if(student_final > 40 && student_final < average_final102) student_final_gpa = 2.50;
			else if(student_final < 40 && student_final < average_final102) student_final_gpa = 1.00;
		}
		
		if(match == 0) return -1;
		else{
		student_average_gpa = (student_final_gpa + student_mt_gpa) / 2;	
		printf("Course ID: %d",student_course_id);		
		return student_average_gpa;
	    }
				
}

void pass_or_fail(FILE *info_fp){
	
	    int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, student_counter108 = 0, student_counter102 = 0;
    	int read_id, read_mt, read_final, read_course_id, student_check = 1;
    	double average_mt108, average_mt102, average_final108, average_final102; 
    	double sum_mt108=0, sum_final108=0, sum_mt102=0, sum_final102=0;
    	double student_mt_gpa, student_final_gpa, student_average_gpa;
    	
    	while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){  	
    	if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		
    		if(read_course_id == 108){
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    		
    		if(read_course_id == 108)
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}	
    		
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;    	
		}		
				
		average_mt108 = (sum_mt108 / student_counter108);
		average_final108 = (sum_final108 / student_counter108);
		average_mt102 = (sum_mt102 / student_counter102);
		average_final102 = (sum_final102 / student_counter102);
		
		fclose(info_fp);
		
		info_fp = fopen("first 1.txt","r");
		while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){
		if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		   		
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    	}	
    	else if(element4 == -1 && element5 == -1) student_check = -1; 
  		
  		if(read_course_id == 108){		
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > 40 && read_mt > average_mt108) student_mt_gpa = 3.50;	
			else if(read_mt < 40 && read_mt > average_mt108) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt108) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt108) student_mt_gpa = 1.00;				
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final108) student_final_gpa = 3.50;	
			else if(read_final > 40 && read_final > average_final108) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final108) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final108) student_final_gpa = 1.00;
		}
		else if(read_course_id == 102){
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > average_mt102) student_mt_gpa = 3.50;	
			else if(read_mt > 40 && read_mt > average_mt102) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt102) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt102) student_mt_gpa = 1.00;
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final102) student_final_gpa = 3.50;	
			else if(read_final < 40 && read_final > average_final102) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final102) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final102) student_final_gpa = 1.00;
		}

		student_average_gpa = (student_final_gpa + student_mt_gpa) / 2;
		
		if(student_check == 1){
			if(student_average_gpa < 1.75) printf("ID:%d Class: %d Letter Grade: F (FAIL) \n",read_id,read_course_id);
			else if(student_average_gpa < 2.75) printf("ID:%d Class: %d Letter Grade: D (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.25) printf("ID:%d Class: %d Letter Grade: C (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.75) printf("ID:%d Class: %d Letter Grade: B (PASS) \n",read_id,read_course_id);
    		else printf("ID:%d Class: %d Letter Grade: A (PASS) \n",read_id,read_course_id);
    	}	
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;   		
		}	
}

void print_course_id(FILE *info_fp, int student_id){
	
	int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, read_id, read_course_id, counter = 0;   	
    	
    while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){  	
    	
    	if(element4 != -1 && element5 != -1){
  			
  			read_id = element1;
    		read_course_id = element5;
    		   		
    	}
    	else if(element4 != -1 && element5 == -1){
    		
    		read_id = element1;
    		read_course_id = element4;  			
    	}
    	
    	else if(element4 == -1 && element5 == -1){
    		
    		read_id = element1;
    		read_course_id = -1; 			
    	}	
    	
    	if(student_id == read_id && read_course_id != -1){ 
    	printf("Course: %d\n",read_course_id);  
    	counter++;  
    	}
    	
	}
	if(counter == 0) printf("Invalid Student ID!\n");
}

void course_pass_or_fail(FILE *info_fp, int course_id){	
	    
	    int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, student_counter108 = 0, student_counter102 = 0;
    	int read_id, read_mt, read_final, read_course_id;
    	double average_mt108, average_mt102, average_final108, average_final102; 
    	double sum_mt108=0, sum_final108=0, sum_mt102=0, sum_final102=0;
    	double student_mt_gpa, student_final_gpa, student_average_gpa;
    	
    	while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){  	
    	if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		
    		if(read_course_id == 108){
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    		
    		if(read_course_id == 108)
				sum_mt108 += read_mt;
				sum_final108 += read_final;
    			student_counter108++;
    		}
    		else if(read_course_id == 102){
				sum_mt102 += read_mt;
				sum_final102 += read_final;
    			student_counter102++;
    		}	
    		
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;    	
		}
		
				
		average_mt108 = (sum_mt108 / student_counter108);
		average_final108 = (sum_final108 / student_counter108);
		average_mt102 = (sum_mt102 / student_counter102);
		average_final102 = (sum_final102 / student_counter102);
		
		fclose(info_fp);
		
		info_fp = fopen("first 1.txt","r");
		while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){
		if(element4 != -1 && element5 != -1){
    		read_id = element1;
    		read_mt = (element2 + element3) / 2;
    		read_final = element4;
    		read_course_id = element5;
    		   		
    	}
    	else if(element4 != -1 && element5 == -1){
    		read_id = element1;
    		read_mt = element2;
    		read_final = element3;
    		read_course_id = element4;  			
    	}	
  		

  		if(read_course_id == 108){		
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > 40 && read_mt > average_mt108) student_mt_gpa = 3.50;	
			else if(read_mt < 40 && read_mt > average_mt108) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt108) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt108) student_mt_gpa = 1.00;				
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final108) student_final_gpa = 3.50;	
			else if(read_final > 40 && read_final > average_final108) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final108) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final108) student_final_gpa = 1.00;
		}
		else if(read_course_id == 102){
			if(read_mt > 90) student_mt_gpa = 4.00;
			else if(read_mt > average_mt102) student_mt_gpa = 3.50;	
			else if(read_mt > 40 && read_mt > average_mt102) student_mt_gpa = 3.00;
			else if(read_mt > 40 && read_mt < average_mt102) student_mt_gpa = 2.50;
			else if(read_mt < 40 && read_mt < average_mt102) student_mt_gpa = 1.00;
			
			if(read_final > 90) student_final_gpa = 4.00;
			else if(read_final > average_final102) student_final_gpa = 3.50;	
			else if(read_final < 40 && read_final > average_final102) student_final_gpa = 3.00;
			else if(read_final > 40 && read_final < average_final102) student_final_gpa = 2.50;
			else if(read_final < 40 && read_final < average_final102) student_final_gpa = 1.00;
		}
		
		student_average_gpa = (student_final_gpa + student_mt_gpa) / 2;
		
		if(course_id ==read_course_id){
			if(student_average_gpa < 1.75) printf("ID:%d Class: %d Letter Grade: F (FAIL) \n",read_id,read_course_id);
			else if(student_average_gpa < 2.75) printf("ID:%d Class: %d Letter Grade: D (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.25) printf("ID:%d Class: %d Letter Grade: C (PASS) \n",read_id,read_course_id);
    		else if(student_average_gpa < 3.75) printf("ID:%d Class: %d Letter Grade: B (PASS) \n",read_id,read_course_id);
    		else printf("ID:%d Class: %d Letter Grade: A (PASS) \n",read_id,read_course_id);
    	}	
    	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;   		
		}
}

void number_of_classes(FILE *info_fp, int id){

	int element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1, counter = 0;
	
	while(fscanf(info_fp,"%d;%d;%d;%d;%d", &element1, &element2, &element3, &element4, &element5) != EOF){
	
	if(element1 == id && element3 == 500){ 
		printf("Number of Classes: %d\n", element2);
		counter = 1;
	}
	
	element1 = -1, element2 = -1, element3 = -1, element4 = -1, element5 = -1;
	}
	
	if(counter == 0) printf("This is not a Instructor ID!\n");

}

void role_department(FILE *id_fp, char initial){
	
	int element1, department, i, finish = 0, counter = 0;
	char element2, temp1;
   
    while(fscanf(id_fp,"%d;", &element1) != EOF){

		while(finish != 1){
		fscanf(id_fp,"%c", &temp1);

		if(temp1 == ';') finish = 1;
		}			
		finish = 0;
		while(finish != 1){
		fscanf(id_fp,"%c", &temp1);

		if(temp1 == ';') finish = 1;
		}
		finish = 0;
		while(finish != 1){
		fscanf(id_fp,"%c", &temp1);

		if(temp1 == ';') finish = 1;
		}
		finish = 0;
		while(finish != 1){
		fscanf(id_fp,"%c", &temp1);

		if(temp1 == ';') finish = 1;
		}
		fscanf(id_fp,"%d;", &department);

   		if((initial == 's' && department == 100) || (initial == 'i' && department == 500)){
   		printf("ID: %d, Department ID: %d\n",element1, department);
   		}
   		while(temp1 = getc(id_fp) != '\n') {
   		
   		}		
   	}
   		if(initial != 's' && initial != 'i') printf("This is not a initial letter of a role!\n");
}

int main(){

int id;
double gpa;
char initial, menu = '0';  
	
	FILE *first;
	FILE *second;    
    
    while(menu != 'e' && menu != 'E'){  
		printf("'P' for class pass or fail list\n");
		printf("'N' for first initial letter pass or fail list\n");
		printf("'G' for Student Gpa and letter grade\n");
		printf("'C' for Course pass or fail list\n");
		printf("'T' for Number of classes of Instructor\n");
		printf("'D' for initial letter of role to department list\n");
		printf("'L' for Student course id\n");
		printf("'E' for exit\n");
        printf("Enter Your Choice: ");
        scanf(" %c",&menu);     
        switch (menu){
            
            case 'p':
            case 'P': 
                first = fopen("first 1.txt","r");
                pass_or_fail(first);
                fclose(first);
                break;
	
            case 'n':
            case 'N':
                first = fopen("first 1.txt","r");
                printf("First initial: ");
                scanf(" %c",&initial);
                initial_pass_or_fail(first,initial);
                fclose(first);
                break;

            case 'g':
            case 'G':    
            	first = fopen("first 1.txt","r");
            	printf("Student ID: ");
            	scanf("%d",&id);
                gpa = average_grade(first, id);
                fclose(first);
                if(gpa != -1){
                	if(gpa < 1.75) printf(", GPA: %.2f, Letter Grade: F\n",gpa);
	    			else if(gpa < 2.75) printf(", GPA: %.2f, Letter Grade: D\n",gpa);
	    			else if(gpa < 3.25) printf(", GPA: %.2f, Letter Grade: C\n",gpa);
	    			else if(gpa < 3.75) printf(", GPA: %.2f, Letter Grade: B\n",gpa);
	    			else printf(", GPA: %.2f, Letter Grade: A\n",gpa);
	    		}
	    		else printf("Invalid Student ID!\n");	
                break;

            case 'c':
            case 'C':
                first = fopen("first 1.txt","r");
            	printf("Course ID: ");
            	scanf("%d",&id);
                course_pass_or_fail(first, id);
                fclose(first);
                break;
	
            case 't':
            case 'T':
                first = fopen("first 1.txt","r");
                printf("Instructor ID: ");	
                scanf("%d",&id);
                number_of_classes(first,id);
                fclose(first);
                break;
	
            case 'd':
            case 'D':
                second = fopen("second 1.txt","r");	
                printf("Initial letter of role: ");
                scanf(" %c",&initial);
                role_department(second, initial);
                fclose(second);
                break;

            case 'l':
            case 'L':
           		first = fopen("first 1.txt","r");
                printf("Student ID: ");
                scanf("%d",&id);
                print_course_id(first,id);
                fclose(first);
                break;

            case 'e':
            case 'E':
            	printf("bye bye!\n");
                break;
        
            default: printf("Invalid Selection\n");        
        }
    }

    return 0;
}
