#include <stdio.h>

char READ_NEW(FILE* first, FILE* second, FILE* third, FILE* fourth, FILE *readed_news, FILE* all_news){

	char read, character, yes_no;
	int check = 0, find = 0, read_again = 1;
	printf("Which news do you want to read?:");
	scanf(" %c",&read);
	all_news = fopen("all_news_id.txt","r");
	while((character = fgetc(all_news)) != EOF){
		if(character == read) find = 1;
	}
	fclose(all_news);
	if(find == 0){
	 	printf("No such news found\n");	
		return 'e';
	}
	readed_news = fopen("readed_news_id.txt","r");
	while((character = fgetc(readed_news)) != EOF){
		if(character == read) check = 1;
	}
	fclose(readed_news);
	
	if(check == 1){
	 	printf("This new is readed. Do you want to read again? Yes(1)/No(0):");
		scanf("%d",&read_again);
	}	
	if(read_again == 1){	
		
		if(check != 1){		
			readed_news = fopen("readed_news_id.txt","a");
			fprintf(readed_news,"%c\n",read);
			fclose(readed_news);
		 }
		
		switch(read){
			case '1':
				first = fopen("1.txt","r");
				printf("\n");
				while((character = fgetc(first)) != EOF){
				printf("%c",character);
				}
				printf("\n");
				fclose(first);	
				break;
		
			case '2':
				second = fopen("2.txt","r");
				printf("\n");
				while((character = fgetc(second)) != EOF){
				printf("%c",character);
				}
				printf("\n\n");
				fclose(second);
				break;
			
			case '3':
				third = fopen("3.txt","r");
				printf("\n");
				while((character = fgetc(third)) != EOF){
				printf("%c",character);
				}
				printf("\n");
				fclose(third);
				break;
							
			case '4':
				fourth = fopen("4.txt","r");
				printf("\n");
				while((character = fgetc(fourth)) != EOF){
				printf("%c",character);
				}
				printf("\n\n\n");
				fclose(fourth);
				break;
			
			default: 
			printf("Error!\n");			
		}
	

		while(1){
		printf("Do you want to continue? Yes(y)/No(n):");
		scanf(" %c",&yes_no);
		printf("\n");
		if(yes_no == 'y' || yes_no == 'Y' || yes_no == 'n' || yes_no == 'N')
		return yes_no;
		else printf("Invalid Character!\n");
		}	
	}
}

char LIST_THE_READED_NEWS(FILE *readed_news){

	int counter = 0;
	char character, yes_no;
	readed_news = fopen("readed_news_id.txt","r");
	printf("Readed news are listed below:\n");
	while((character = fgetc(readed_news)) != EOF){
		if (character == '1' || character == '2' || character == '3' || character == '4'){ 
			printf("%c. new is readed\n",character);
			counter++;
		}	
	}
	fclose(readed_news);
	
	if(counter == 0) printf("\nNo news read!\n\n");
	
	while(1){
	printf("Do you want to continue? Yes(y)/No(n):");
	scanf(" %c",&yes_no);
	printf("\n");
	if(yes_no == 'y' || yes_no == 'Y' || yes_no == 'n' || yes_no == 'N')
	return yes_no;
	else printf("Invalid Character!\n");
	}
}

double g(double x){

return x*x;
	
}

double f(double x){

return (x*x*x - x*x + 2);

}

char GET_DECRYPTED_INFORMATION(FILE* first, FILE* second, FILE* third, FILE* fourth, FILE* all_news){

	int decrypt, i, counter = 0, find = 0, id;
	char character, yes_no;
	double magic_numbers[10];
	double result_f = 0, result_g = 0;
	for(i=0;i<10;i++){
		magic_numbers[i] = -1;
	}
	printf("Which news would you like to decrypt?:");
	scanf("%d",&decrypt);
	all_news = fopen("all_news_id.txt","r");
	while((fscanf(all_news,"%d",&id)) != EOF){
		if(id == decrypt) find = 1;
	}
	fclose(all_news);
	if(find == 0){
	 	printf("No such news found\n");	
		return 'e';
	}
	switch(decrypt){
		case 1:
			first = fopen("1.txt","r");
			while((character = fgetc(first)) != EOF){
				if(character == '#'){ 				
				fscanf(first,"%lf",&magic_numbers[counter]); 
				counter++;
				}
			}
			fclose(first);
			printf("First Experiment Key = ");
			break;
			
		case 2:
			second = fopen("2.txt","r");
			while((character = fgetc(second)) != EOF){
				if(character == '#'){ 				
				fscanf(second,"%lf",&magic_numbers[counter]); 
				counter++;
				}
			}
			fclose(second);
			printf("Second Experiment Key = ");
			break;
			
		case 3:
			third = fopen("3.txt","r");
			while((character = fgetc(third)) != EOF){
				if(character == '#'){ 				
				fscanf(third,"%lf",&magic_numbers[counter]); 
				counter++;
				}
			}
			fclose(third);
			printf("Third Experiment Key = ");
			break;	
	
		case 4:
			fourth = fopen("4.txt","r");
			while((character = fgetc(fourth)) != EOF){
				if(character == '#'){ 				
				fscanf(fourth,"%lf",&magic_numbers[counter]); 
				counter++;
				}
			}	
			fclose(fourth);
			printf("Fourth Experiment Key = ");
			break;
	
		default:
	}
	for(i=0;i<10;i++){
		if(magic_numbers[i != -1]){
			result_f = f(magic_numbers[i]);
			result_g += g(result_f);
		}	
	}

	printf("%.2lf\n\n",result_g);

	while(1){
	printf("Do you want to continue? Yes(y)/No(n):");
	scanf(" %c",&yes_no);
	printf("\n");
	if(yes_no == 'y' || yes_no == 'Y' || yes_no == 'n' || yes_no == 'N')
	return yes_no;
	else printf("Invalid Character!\n");
	}
}

int main(){

	char menu, character;
	FILE *first, *second, *third, *fourth, *readed_news, *all_news;
			
	first = fopen("1.txt","r");
	second = fopen("2.txt","r");
	third = fopen("3.txt","r");
	fourth = fopen("4.txt","r");
				
	printf("**********Daily Press**********\n\n");
	printf("Today's news are listed for you :\n\n");
		
	printf("Title of 1. ");
	while((character = fgetc(first)) != '\n'){
		printf("%c",character);
	}
	printf("\n");
	
	printf("Title of 2. ");
	while((character = fgetc(second)) != '\n'){
		printf("%c",character);
	}
	printf("\n");
	
	printf("Title of 3. ");
	while((character = fgetc(third)) != '\n'){
		printf("%c",character);
	}
	printf("\n");
	printf("Title of 4. ");
	
	while((character = fgetc(fourth)) != '\n'){
		printf("%c",character);
	}
	printf("\n");
				
	fclose(first);
	fclose(second);
	fclose(third);
	fclose(fourth);	
	
	do{
		
		printf("What do you want to do?\n");
		printf("a.Read a new\n");
		printf("b.List the readed news\n");
		printf("c.Get decrypted information from the news\n");
		printf("Choice:");
		scanf(" %c",&menu);
		switch(menu){
			case 'a':
			case 'A':
				menu = READ_NEW(first,second,third,fourth,readed_news,all_news);
				break;
			
			case 'b':
			case 'B':
				menu = LIST_THE_READED_NEWS(readed_news);
				break;
				
			case 'c':
			case 'C':
				menu = GET_DECRYPTED_INFORMATION(first,second,third,fourth,all_news);
				break;
			case 'n':
			case 'N':
				printf("Bye Bye!\n");	
			default:
				printf("Invalid Character!\n");
			
		}
	
	}while(menu != 'n' && menu != 'N');
	
	return 0;

}
