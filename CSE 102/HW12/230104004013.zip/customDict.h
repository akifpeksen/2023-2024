#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union Value{
	char charValue;
	int intValue;
	float floatValue;
	double doubleValue;
};

struct Item{
	char* key;
	char* dtype;
	union Value value;
};

struct CustomDict{
	struct Item* items;
	int capacity;
	int size;
};

struct CustomDict* create_dict(){
	struct CustomDict *myDict = (struct CustomDict*) malloc(sizeof(struct CustomDict));
	myDict->items = NULL;
	myDict->capacity = 0;
	myDict->size = 0;
	return myDict;
}

void add_item(struct CustomDict* dict, char* key, union Value* value, char* type){
	
	if(dict->capacity == 0){ 
		dict->items = (struct Item*) malloc(5*sizeof(struct Item));
		dict->capacity = 5;	
	}	
	else if(dict->size == dict->capacity){ 
		dict->items = realloc(dict->items, (dict->capacity+5)*sizeof(struct Item));
		dict->capacity += 5;
	}
	
	dict->items[dict->size].key = (char*) malloc(sizeof(char)*strlen(key)+1);
	strcpy(dict->items[dict->size].key,key);
	dict->items[dict->size].dtype = (char*) malloc(sizeof(char)*strlen(type)+1);
	strcpy(dict->items[dict->size].dtype,type);
	dict->items[dict->size].value = *value;
	dict->size++;

}

void delete_item(struct CustomDict* dict, char* key){
	int i, k;
	for(i=0;i<(dict->size);i++){
		if(strcmp(dict->items[i].key,key)==0){
			free(dict->items[i].key);
			free(dict->items[i].dtype);
			for(k=i;k<(dict->size-i);k++){
				dict->items[k] = dict->items[k+1];
			}
			i--;
			dict->size--;
		}		
	}
}

void set_value(struct CustomDict* dict, char* key, union Value* value, char* type){
	int i;
	for(i=0;i<dict->size;i++){ 
		if(strcmp(dict->items[i].key,key) == 0){ 
			dict->items[i].value = *value;		
			free(dict->items[i].dtype);
			dict->items[i].dtype = (char*) malloc(sizeof(char)*strlen(type)+1);
			strcpy(dict->items[i].dtype,type);
		}	
	}		
}

union Value* search_item(struct CustomDict* dict, char* key){
	int i;
	for(i=0;i<dict->size;i++) if(strcmp(dict->items[i].key,key) == 0) return &(dict->items[i].value);
}

void sort_dict(struct CustomDict* dict){

	int i, k;
	for(i=0;i<dict->size;i++){
		for(k=0;k<dict->size;k++){
			if(k != dict->size-1 && strcmp(dict->items[k].key,dict->items[k+1].key) > 0){
				dict->items = realloc(dict->items, (dict->capacity+1)*sizeof(struct Item));
				dict->capacity++;
				dict->items[dict->capacity-1] = dict->items[k];
				dict->items[k] = dict->items[k+1];
				dict->items[k+1] = dict->items[dict->capacity-1];
			}
		}
	}
}

void print_dict(struct CustomDict* dict){
	int i;
	for(i=0;i<(dict->size);i++){
		if(strcmp(dict->items[i].dtype,"int")==0){
			if(i==0 || strcmp(dict->items[i].key,dict->items[i-1].key) != 0) printf("Key: %s\nItems: ",dict->items[i].key);
			else printf(", ");
			printf("%d",dict->items[i].value.intValue);
		}
		else if(strcmp(dict->items[i].dtype,"char")==0){
			if(i==0 || strcmp(dict->items[i].key,dict->items[i-1].key) != 0) printf("Key: %s\nItems: ",dict->items[i].key);
			else printf(", ");
			printf("%c",dict->items[i].value.charValue);
		}
		else if(strcmp(dict->items[i].dtype,"double")==0){
			if(i==0 || strcmp(dict->items[i].key,dict->items[i-1].key) != 0) printf("Key: %s\nItems: ",dict->items[i].key);
			else printf(", ");
			printf("%lf",dict->items[i].value.doubleValue);
		}
		else if(strcmp(dict->items[i].dtype,"float")==0){
			if(i==0 || strcmp(dict->items[i].key,dict->items[i-1].key) != 0) printf("Key: %s\nItems: ",dict->items[i].key);
			else printf(", ");
			printf("%f",dict->items[i].value.floatValue);
		}
		if(i != dict->size-1 && strcmp(dict->items[i].key,dict->items[i+1].key) != 0) printf("\n");
	}
	printf("\n");
}

void free_dict(struct CustomDict* dict){
	int i;
	for(i=0;i<(dict->capacity);i++){
		free(dict->items[i].key);
		free(dict->items[i].dtype);
	}
		free(dict->items);
		free(dict);
}

int read_csv(struct CustomDict* dict, const char* filename){
	FILE* myFile;
	myFile = fopen(filename,"r");
	if(myFile == NULL) return 0;
	else{
		char type[10], key[20];
		int counter = 0, row = 0, flag = 0, item_counter;
		char c;
		int i;
		double d;
		float f;
		while(!feof(myFile)){

			if(flag == 0){	
				fscanf(myFile,"%c",&c);
				if(c != ','){
					type[counter] = c;
					counter++;
				}	
				else{
					type[counter] = '\0';
					counter = 0; 
					flag = 1;	
				}
			}
			else if(flag == 1){	
				fscanf(myFile,"%c",&c);
				if(c != ',' && c != ' '){
					key[counter] = c;
					counter++;
				}	
				else if(c==','){
					key[counter] = '\0';
					counter = 0; 
					flag = 2;		
				}
			}
			else if(flag == 2){
				if(strcmp(type,"int")==0){
					fscanf(myFile,"%d",&i);
					fscanf(myFile,"%c",&c);
					if(c==','){
					fscanf(myFile,"%c",&c); 
					}
					if(c=='\n'){ 
					flag = 0;
					}
				}
				else if(strcmp(type,"char")==0){				
					fscanf(myFile,"%c",&c);	
					if(c == ' ') fscanf(myFile,"%c",&c);		
					fscanf(myFile,"%c",&c);
					if(c==','){
					fscanf(myFile,"%c",&c); 
					}
					if(c=='\n'){ 
					flag = 0;
					}

		
				}
				else if(strcmp(type,"float")==0){
					fscanf(myFile,"%f",&f);
					fscanf(myFile,"%c",&c);
					if(c==','){
					fscanf(myFile,"%c",&c); 
					}
					if(c=='\n'){ 
					flag = 0;
					}
				}
				else if(strcmp(type,"double")==0){
					fscanf(myFile,"%lf",&d);			
					fscanf(myFile,"%c",&c);
					if(c==','){
					fscanf(myFile,"%c",&c); 
					}
					else fscanf(myFile,"%c",&c);
					if(c=='\n'){ 
					flag = 0;
					}
				}
			}	
		}	
		fclose(myFile);
		if(myFile == NULL) return 0;
		return 1;
	}
	fclose(myFile);
}


