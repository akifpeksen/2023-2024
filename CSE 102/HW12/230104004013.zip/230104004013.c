#include "customDict.h"
void main(){
	union Value myValue;
	struct CustomDict *myDict = create_dict();
	myValue.intValue = 12;
	add_item(myDict,"first",&myValue,"int");
	myValue.charValue = 'f';
	add_item(myDict,"second",&myValue,"char");
	myValue.floatValue = 44.442;
	add_item(myDict,"third",&myValue,"float");
	myValue.doubleValue = 5555.1122;
	add_item(myDict,"fourth",&myValue,"double");
	myValue.intValue = 10;
	add_item(myDict,"first",&myValue,"int");
	myValue.intValue = 144;
	add_item(myDict,"first",&myValue,"int");
	myValue.charValue = 'A';
	add_item(myDict,"second",&myValue,"char");
	myValue.doubleValue = 1.555;
	add_item(myDict,"fourth",&myValue,"double");	
	printf("--1--\n");
	print_dict(myDict);
	sort_dict(myDict);	
	printf("--2--\n");
	print_dict(myDict);
	delete_item(myDict,"second");	
	printf("--3--\n");
	print_dict(myDict);
	myValue.charValue = 'c';
	set_value(myDict,"first",&myValue,"char");
	printf("--4--\n");
	print_dict(myDict);
}
