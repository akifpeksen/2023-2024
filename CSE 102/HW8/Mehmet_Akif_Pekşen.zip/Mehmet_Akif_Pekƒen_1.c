#include <stdio.h>
#include <string.h>

void sort_people_by_age(FILE* input1){
	char str1[15], str2[15], str3[25], str4[25], c = '0';
	int age, counter = 0, i = 0, temp, j;
	int arrayAge[23]; 
	printf("Name                  Surname               Age          Branch1              Branch2\n\n");
	input1 = fopen("input1.txt","r");
	while(fscanf(input1,"%c",&c) != EOF){
		if(counter == 0){
			switch(c){
				case '1':
					age = 10;
					counter = 1;
					break;
				case '2':
					age = 20;
					counter = 1;
					break;
				case '3':
					age = 30;
					counter = 1;
					break;
				case '4':
					age = 40;
					counter = 1;
					break;	
				case '5':
					age = 50;
					counter = 1;
					break;
				case '6':
					age = 60;
					counter = 1;
					break;
				case '7':
					age = 70;
					counter = 1;
					break;
				case '8':
					age = 80;
					counter = 1;
					break;
				case '9':
					age = 90;
					counter = 1;
					break;	
				default:
					continue;		
			} 
		}	
		else if(counter == 1){
			switch(c){
				case '0':
					counter = 2;
					break;
				case '1':
					age += 1;
					counter = 2;
					break;
				case '2':
					age += 2;
					counter = 2;
					break;
				case '3':
					age += 3;
					counter = 2;
					break;
				case '4':
					age += 4;
					counter = 2;
					break;	
				case '5':
					age += 5;
					counter = 2;
					break;
				case '6':
					age += 6;
					counter = 2;
					break;
				case '7':
					age += 7;
					counter = 2;
					break;
				case '8':
					age += 8;
					counter = 2;
					break;
				case '9':
					age += 9;
					counter = 2;
					break;	
				default:
					continue;		
			}	
		}	
		else if(counter == 2){ 
			arrayAge[i] = age;
			counter = 0;
			i++;
		}			
	}
	fclose(input1);
	for(i=0;i<22;i++){
		for(j=0;j<22;j++){
			if(arrayAge[j] > arrayAge[j+1]){
				temp = arrayAge[j];
				arrayAge[j] = arrayAge[j+1];
				arrayAge[j+1] = temp;
			}
		}
	}	
	i=0;
	for(j=0;j<23;j++){
		if(arrayAge[j] == arrayAge[j+1]) j++;
		input1 = fopen("input1.txt","r");
		while(fscanf(input1,"%c",&c) != EOF){
			if(counter == 0){
				if(c == ','){ 
					counter = 1;
					str1[i] = '\0';
					i=0;
				}
				else{ 
					str1[i] = c;
					i++;
				}	
			}
			else if(counter == 1){
				if(c == ','){ 
					counter = 2;
					str2[i] = '\0';
					i=0;
					
				}
				else{ 
					str2[i] = c;
					i++;
				}	
			}
			else if(counter == 2){
				switch(c){
					case '1':
						age = 10;
						counter = 3;
						break;
					case '2':
						age = 20;
						counter = 3;
						break;
					case '3':
						age = 30;
						counter = 3;
						break;
					case '4':
						age = 40;
						counter = 3;
						break;	
					case '5':
						age = 50;
						counter = 3;
						break;
					case '6':
						age = 60;
						counter = 3;
						break;
					case '7':
						age = 70;
						counter = 3;
						break;
					case '8':
						age = 80;
						counter = 3;
						break;
					case '9':
						age = 90;
						counter = 3;
						break;	
					default:
						continue;		
				} 
			}	
			else if(counter == 3){
				switch(c){
					case '0':
						counter = 4;
						break;
					case '1':
						age += 1;
						counter = 4;
						break;
					case '2':
						age += 2;
						counter = 4;
						break;
					case '3':
						age += 3;
						counter = 4;
						break;
					case '4':
						age += 4;
						counter = 4;
						break;	
					case '5':
						age += 5;
						counter = 4;
						break;
					case '6':
						age += 6;
						counter = 4;
						break;
					case '7':
						age += 7;
						counter = 4;
						break;
					case '8':
						age += 8;
						counter = 4;
						break;
					case '9':
						age += 9;
						counter = 4;
						break;	
					default:
						continue;		
				}		
			}
			else if(counter == 4){ 
			counter = 5;
			}
			else if(counter == 5){
				if(c == ','){ 
					counter = 6;
					str3[i] = '\0';
					i=0;	
				}
				else if(c == '\n'){
					str3[i] = '\0';
					if(age == arrayAge[j]) printf("%-20s %-22s %-11d %s\n\n",str1,str2,age,str3);
					counter = 0;
					i=0;
				}
				else{ 
					str3[i] = c;
					i++;
				}	
			}
			else if(counter == 6){
				if(c == '\n'){ 
					str4[i] = '\0';
					if(age == arrayAge[j]) printf("%-20s %-22s %-11d %-20s %s\n\n",str1,str2,age,str3,str4);			
					counter = 0;
					i=0;	
				}
				else{ 
					str4[i] = c;
					i++;
				}	
			}	
		}
		fclose(input1);
	}
}

void sort_people_by_branch(FILE* input1){
	char str1[15], str2[15], str3[25], str4[25], c = '0';
	int age, counter = 0, i = 0, temp, j, k, m;
	char branches[][20] = {
        "BOTANY",
        "CHEMISTRY",
        "COMPUTER SCIENCE",
        "CYTOGENETICS",
        "GENETICS",
        "GEOLOGY",
        "IMMUNOLOGY",
        "MATERIALS SCIENCE",
        "MATHEMATICS",
        "MEDICINE",
        "PHARMACY",
        "PHYSICS",
        "PHILOSOPHY"
    };
	int arrayAge[23]; 
	printf("Name                  Surname               Age          Branch1              Branch2\n\n");
	input1 = fopen("input1.txt","r");
	while(fscanf(input1,"%c",&c) != EOF){
		if(counter == 0){
			switch(c){
				case '1':
					age = 10;
					counter = 1;
					break;
				case '2':
					age = 20;
					counter = 1;
					break;
				case '3':
					age = 30;
					counter = 1;
					break;
				case '4':
					age = 40;
					counter = 1;
					break;	
				case '5':
					age = 50;
					counter = 1;
					break;
				case '6':
					age = 60;
					counter = 1;
					break;
				case '7':
					age = 70;
					counter = 1;
					break;
				case '8':
					age = 80;
					counter = 1;
					break;
				case '9':
					age = 90;
					counter = 1;
					break;	
				default:
					continue;		
			} 
		}	
		else if(counter == 1){
			switch(c){
				case '0':
					counter = 2;
					break;
				case '1':
					age += 1;
					counter = 2;
					break;
				case '2':
					age += 2;
					counter = 2;
					break;
				case '3':
					age += 3;
					counter = 2;
					break;
				case '4':
					age += 4;
					counter = 2;
					break;	
				case '5':
					age += 5;
					counter = 2;
					break;
				case '6':
					age += 6;
					counter = 2;
					break;
				case '7':
					age += 7;
					counter = 2;
					break;
				case '8':
					age += 8;
					counter = 2;
					break;
				case '9':
					age += 9;
					counter = 2;
					break;	
				default:
					continue;		
			}	
		}	
		else if(counter == 2){ 
			arrayAge[i] = age;
			counter = 0;
			i++;
		}			
	}
	fclose(input1);
	for(i=0;i<22;i++){
		for(j=0;j<22;j++){
			if(arrayAge[j] > arrayAge[j+1]){
				temp = arrayAge[j];
				arrayAge[j] = arrayAge[j+1];
				arrayAge[j+1] = temp;
			}
		}
	}	
	i=0;
	for(k=0;k<13;k++){
		for(j=0;j<23;j++){
			if(arrayAge[j] == arrayAge[j+1]) j++;
			input1 = fopen("input1.txt","r");
			while(fscanf(input1,"%c",&c) != EOF){
				if(counter == 0){
					if(c == ','){ 
						counter = 1;
						str1[i] = '\0';
						i=0;
					}
					else{ 
						str1[i] = c;
						i++;
					}	
				}
				else if(counter == 1){
					if(c == ','){ 
						counter = 2;
						str2[i] = '\0';
						i=0;		
					}
					else{ 
						str2[i] = c;
						i++;
					}	
				}
				else if(counter == 2){
					switch(c){
						case '1':
							age = 10;
							counter = 3;
							break;
						case '2':
							age = 20;
							counter = 3;
							break;
						case '3':
							age = 30;
							counter = 3;
							break;
						case '4':
							age = 40;
							counter = 3;
							break;	
						case '5':
							age = 50;
							counter = 3;
							break;
						case '6':
							age = 60;
							counter = 3;
							break;
						case '7':
							age = 70;
							counter = 3;
							break;
						case '8':
							age = 80;
							counter = 3;
							break;
						case '9':
							age = 90;
							counter = 3;
							break;	
						default:
							continue;		
					} 
				}	
				else if(counter == 3){
					switch(c){
						case '0':
							counter = 4;
							break;
						case '1':
							age += 1;
							counter = 4;
							break;
						case '2':
							age += 2;
							counter = 4;
							break;
						case '3':
							age += 3;
							counter = 4;
							break;
						case '4':
							age += 4;
							counter = 4;
							break;	
						case '5':
							age += 5;
							counter = 4;
							break;
							case '6':
							age += 6;
							counter = 4;
							break;
						case '7':
							age += 7;
							counter = 4;
							break;
						case '8':
							age += 8;
							counter = 4;
							break;
						case '9':
							age += 9;
							counter = 4;
							break;	
						default:
							continue;		
					}		
				}
				else if(counter == 4){ 
				counter = 5;
				}
				else if(counter == 5){
					if(c == ','){ 
						counter = 6;
						str3[i] = '\0';
						i=0;	
					}
					else if(c == '\n'){
						str3[i] = '\0';
						if(age == arrayAge[j] && strstr(str3,branches[k]) != NULL){ 
						printf("%-20s %-22s %-11d %s\n\n",str1,str2,age,str3);
						}	
						counter = 0;
						i=0;
					}
					else{ 
						str3[i] = c;
						i++;
					}	
				}
				else if(counter == 6){
					if(c == '\n'){ 
						str4[i] = '\0';
						if(age == arrayAge[j] && strstr(str3,branches[k]) != NULL){
						printf("%-20s %-22s %-11d %-20s %s\n\n",str1,str2,age,str3,str4);
						}			
						counter = 0;
						i=0;	
					}
					else{ 
						str4[i] = c;
						i++;
					}	
				}	
			}
			fclose(input1);
		}
	}		
}

void filter_people_by_branch(FILE* input1){
	char str1[15], str2[15], str3[25], str4[25], c = '0';
	int age, counter = 0, i = 0;
	printf("Name                  Surname               Age          Branch1              Branch2\n\n");
	input1 = fopen("input1.txt","r");
	while(fscanf(input1,"%c",&c) != EOF){
		if(counter == 0){
			if(c == ','){ 
				counter = 1;
				str1[i] = '\0';
				i=0;
			}
			else{ 
				str1[i] = c;
				i++;
			}	
		}
		else if(counter == 1){
			if(c == ','){ 
				counter = 2;
				str2[i] = '\0';
				i=0;
				
			}
			else{ 
				str2[i] = c;
				i++;
			}	
		}
		else if(counter == 2){
			switch(c){
				case '1':
					age = 10;
					counter = 3;
					break;
				case '2':
					age = 20;
					counter = 3;
					break;
				case '3':
					age = 30;
					counter = 3;
					break;
				case '4':
					age = 40;
					counter = 3;
					break;	
				case '5':
					age = 50;
					counter = 3;
					break;
				case '6':
					age = 60;
					counter = 3;
					break;
				case '7':
					age = 70;
					counter = 3;
					break;
				case '8':
					age = 80;
					counter = 3;
					break;
				case '9':
					age = 90;
					counter = 3;
					break;	
				default:
					continue;		
			} 
		}	
		else if(counter == 3){
			switch(c){
				case '0':
					counter = 4;
					break;
				case '1':
					age += 1;
					counter = 4;
					break;
				case '2':
					age += 2;
					counter = 4;
					break;
				case '3':
					age += 3;
					counter = 4;
					break;
				case '4':
					age += 4;
					counter = 4;
					break;	
				case '5':
					age += 5;
					counter = 4;
					break;
				case '6':
					age += 6;
					counter = 4;
					break;
				case '7':
					age += 7;
					counter = 4;
					break;
				case '8':
					age += 8;
					counter = 4;
					break;
				case '9':
					age += 9;
					counter = 4;
					break;	
				default:
					continue;		
			}		
		}
		else if(counter == 4){ 
		counter = 5;
		}
		else if(counter == 5){
			if(c == ','){ 
				counter = 6;
				str3[i] = '\0';
				i=0;	
			}
			else if(c == '\n'){
				str3[i] = '\0';		
				if(strstr(str3,"SCIENCE") != NULL){ 	
					printf("%-20s %-22s %-11d %s\n\n",str1,str2,age,str3);
				}
				counter = 0;
				i=0;
			}
			else{ 
				str3[i] = c;
				i++;
			}	
		}
		else if(counter == 6){
			if(c == '\n'){ 
				str4[i] = '\0';
				if(strstr(str3,"SCIENCE") != NULL || strstr(str4,"SCIENCE") != NULL){
					printf("%-20s %-22s %-11d %-20s %s\n\n",str1,str2,age,str3,str4);
				}	
				counter = 0;
				i=0;	
			}
			else{ 
				str4[i] = c;
				i++;
			}	
		}	
	}
	fclose(input1);
}


void filter_people_by_proffession(FILE* input1){
	char str1[15], str2[15], str3[25], str4[25], c = '0';
	int age, counter = 0, i = 0;
	printf("Name                  Surname               Age          Branch1              Branch2\n\n");
	input1 = fopen("input1.txt","r");
	while(fscanf(input1,"%c",&c) != EOF){
		if(counter == 0){
			if(c == ','){ 
				counter = 1;
				str1[i] = '\0';
				i=0;
			}
			else{ 
				str1[i] = c;
				i++;
			}	
		}
		else if(counter == 1){
			if(c == ','){ 
				counter = 2;
				str2[i] = '\0';
				i=0;
				
			}
			else{ 
				str2[i] = c;
				i++;
			}	
		}
		else if(counter == 2){
			switch(c){
				case '1':
					age = 10;
					counter = 3;
					break;
				case '2':
					age = 20;
					counter = 3;
					break;
				case '3':
					age = 30;
					counter = 3;
					break;
				case '4':
					age = 40;
					counter = 3;
					break;	
				case '5':
					age = 50;
					counter = 3;
					break;
				case '6':
					age = 60;
					counter = 3;
					break;
				case '7':
					age = 70;
					counter = 3;
					break;
				case '8':
					age = 80;
					counter = 3;
					break;
				case '9':
					age = 90;
					counter = 3;
					break;	
				default:
					continue;		
			} 
		}	
		else if(counter == 3){
			switch(c){
				case '0':
					counter = 4;
					break;
				case '1':
					age += 1;
					counter = 4;
					break;
				case '2':
					age += 2;
					counter = 4;
					break;
				case '3':
					age += 3;
					counter = 4;
					break;
				case '4':
					age += 4;
					counter = 4;
					break;	
				case '5':
					age += 5;
					counter = 4;
					break;
				case '6':
					age += 6;
					counter = 4;
					break;
				case '7':
					age += 7;
					counter = 4;
					break;
				case '8':
					age += 8;
					counter = 4;
					break;
				case '9':
					age += 9;
					counter = 4;
					break;	
				default:
					continue;		
			}		
		}
		else if(counter == 4){ 
		counter = 5;
		}
		else if(counter == 5){
			if(c == ','){ 
				counter = 6;
				str3[i] = '\0';
				i=0;	
			}
			else if(c == '\n'){
				str3[i] = '\0';		
				if(strncmp(str3," COMPUTER SCIENCE",strlen(" COMPUTER SCIENCE")) == 0){ 	
					printf("%-20s %-22s %-11d %s\n\n",str1,str2,age,str3);
				}
				counter = 0;
				i=0;
			}
			else{ 
				str3[i] = c;
				i++;
			}	
		}
		else if(counter == 6){
			if(c == '\n'){ 
				str4[i] = '\0';
				if(strncmp(str3," COMPUTER SCIENCE",strlen(" COMPUTER SCIENCE")) == 0 && strncmp(str4," MATHEMATICS",strlen(" MATHEMATICS")) != 0){
					printf("%-20s %-22s %-11d %-20s %s\n\n",str1,str2,age,str3,str4);
				}	
				counter = 0;
				i=0;	
			}
			else{ 
				str4[i] = c;
				i++;
			}	
		}	
	}
	fclose(input1);
}

void main(){
	int menu;
	FILE* input1;
	do{
		printf("******menu*****************\n");
		printf("1. Sort and display all individuals by age\n");
		printf("2. Sort and display individuals in the branch by age\n");
		printf("3. Show individiuals with the branch 'SCIENCE'\n");
		printf("4. Show computer scientists who are not mathematicians\n");
		printf("5. Exit\n");
		printf("Choice:");
		scanf("%d",&menu);
		
		switch(menu){
			case 1:
				sort_people_by_age(input1);
				break;
			case 2:
				sort_people_by_branch(input1);
				break;
			case 3:
				filter_people_by_branch(input1);
				break;
			case 4:
				filter_people_by_proffession(input1);
				break;
			case 5:
				printf("Bye Bye!");
				break;		
			default:
				printf("Invalid Value!");							
		}
				
	}while(menu != 5);
}
