#include <stdio.h>
#include <string.h>
#define MAX_COL_COUNT 35

void search_p1(char strs[][MAX_COL_COUNT], int num_rows, int matches[][2], int * num_matches){
	char check_str[] = "***++++***++++***";
	int i;
	char* location;
	int index;
	for(i=0;i<num_rows;i++){
		location = strstr(strs[i],check_str);
		if(location != NULL){
			index = (location - strs[i]);
			matches[(*num_matches)][0] = i+1;
			matches[(*num_matches)][1] = index+1;
			(*num_matches)++;
		} 	
	}
}

void search_p2(char strs[][MAX_COL_COUNT], int num_rows, int matches[][2], int * num_matches){
	int i;

	for(i=0;i<MAX_COL_COUNT;i++){
		if(strs[0][i] == '+' && strs[1][i] == '*' && strs[2][i] == '+' && strs[3][i] == '*' && strs[4][i] == '+'){
			matches[(*num_matches)][0] = 1;
			matches[(*num_matches)][1] = i+1;
			(*num_matches)++;
		}
	}		
}

void main(){
	int num_matches = 0, num_rows = 5;
	int matches[5][2], i=0, j=0;
	char strs[5][MAX_COL_COUNT], character;
	FILE* input2;
	input2 = fopen("input2.txt","r");
	while(fscanf(input2,"%c",&character)!=EOF){
		if(character == '*' || character == '+'){	
			strs[i][j] = character;
			j++;
			if(j==MAX_COL_COUNT-1){
				j=0;
				i++;
			}
		}		
	}
	fclose(input2);
	search_p1(strs,num_rows,matches,&num_matches);
	for(i=0;i<num_matches;i++){
		printf("P1 @ (%d,%d)\n",matches[i][0],matches[i][1]);
	}
	num_matches=0;
	search_p2(strs,num_rows,matches,&num_matches);
	for(i=0;i<num_matches;i++){
		printf("P2 @ (%d,%d)\n",matches[i][0],matches[i][1]);
	}
}
