#include <stdio.h>

int numPathsHome(int street, int avenue){
	if(street == 1 || avenue == 1) return 1;
	return numPathsHome(street-1,avenue) + numPathsHome(street,avenue-1);
}

void main(){

	int street, avenue, result;
	printf("Enter the street number: ");
	scanf("%d",&street);
	printf("street:%d\n",street);
	printf("Enter the avenue number: ");
	scanf("%d",&avenue);
	printf("avenue:%d\n",avenue);
	if(street < 1 || street > 5 || avenue < 1  || avenue > 5) printf("Error!\n");
	else{
		result = numPathsHome(street,avenue);
		printf("Number of optimal paths to take back home: %d\n",result);
	}
}
