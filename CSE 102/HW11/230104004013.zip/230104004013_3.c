#include <stdio.h>
#include <time.h>

struct card{
	const char *face;
	const char *suit;
};

void main() {
	srand(time(NULL));
    int i, temp, rand1, rand2;
    const char *Numbers[] = {"Deuce","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King","Ace"};
    const char *suits[] = {"Hearts", "Diamonds", "Clubs", "Spades"};
    struct card cards[52];

	int random[52];
    for(i = 0; i < 52; i++){
    	random[i] = i;
    }
    
    for(i = 0; i < 500; i++){
    	rand1 = rand()%52;
    	rand2 = rand()%52;
    	temp = random[rand1];
    	random[rand1] = random[rand2];
    	random[rand2] = temp;
    }

    for(i = 0; i < 52; i++){
        cards[i].face = Numbers[random[i] % 13];
        cards[i].suit = suits[random[i] % 4];
    }
  
    
    for(i = 0; i < 52; i++){
        printf("%s of %s\n", cards[random[i]].face, cards[random[i]].suit);
    }

}

