#include <stdio.h>
#include <string.h>

struct Hospital
{
	char* name;
	char citiesServed[3];
};
/* Factorial function */
int factorial(int num){
	int i, result = 1;
	for(i=0;i<num;i++){	
		result *= num;
		num -= 1;
	}

	return result;	
}
/* Combination function for 4 elements */
int combinationW4(int num){
	return	(factorial(4) / (factorial(4-num)*factorial(num)));
}
/* Solution function to find if all cities are covered */
int solution(int hospitalNum, struct Hospital allHospitals[], int turn ,int result){
	
	int i, counter = 0;
	char *cities[] = {"a","b","c","d","e","f"};
	char cover1[] = {'a','b','c'};
	char cover2[] = {'a','c','d'};
	char cover3[] = {'b','f',' '};
	char cover4[] = {'c','e','f'};
	char check[13];

	if(turn == combinationW4(hospitalNum) + 1) return result;
	/* Reset cities */
	allHospitals[0].citiesServed[0] = ' ';
    allHospitals[0].citiesServed[1] = ' ';
    allHospitals[0].citiesServed[2] = ' ';
    allHospitals[1].citiesServed[0] = ' ';
    allHospitals[1].citiesServed[1] = ' ';
    allHospitals[1].citiesServed[2] = ' ';
    allHospitals[2].citiesServed[0] = ' ';
    allHospitals[2].citiesServed[1] = ' ';
    allHospitals[2].citiesServed[2] = ' ';
    allHospitals[3].citiesServed[0] = ' ';
    allHospitals[3].citiesServed[1] = ' ';
    allHospitals[3].citiesServed[2] = ' ';
	if (turn == 1) {
        if (hospitalNum == 1) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
        } else if (hospitalNum == 2) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover2[0];
            allHospitals[1].citiesServed[1] = cover2[1];
            allHospitals[1].citiesServed[2] = cover2[2];
        } else if (hospitalNum == 3) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover2[0];
            allHospitals[1].citiesServed[1] = cover2[1];
            allHospitals[1].citiesServed[2] = cover2[2];
            allHospitals[2].citiesServed[0] = cover3[0];
            allHospitals[2].citiesServed[1] = cover3[1];
            allHospitals[2].citiesServed[2] = cover3[2];
        } else if (hospitalNum == 4) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover2[0];
            allHospitals[1].citiesServed[1] = cover2[1];
            allHospitals[1].citiesServed[2] = cover2[2];
            allHospitals[2].citiesServed[0] = cover3[0];
            allHospitals[2].citiesServed[1] = cover3[1];
            allHospitals[2].citiesServed[2] = cover3[2];
            allHospitals[3].citiesServed[0] = cover4[0];
            allHospitals[3].citiesServed[1] = cover4[1];
            allHospitals[3].citiesServed[2] = cover4[2];
        }
    } else if (turn == 2) {
        if (hospitalNum == 1) {
            allHospitals[0].citiesServed[0] = cover2[0];
            allHospitals[0].citiesServed[1] = cover2[1];
            allHospitals[0].citiesServed[2] = cover2[2];
        } else if (hospitalNum == 2) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover3[0];
            allHospitals[1].citiesServed[1] = cover3[1];
            allHospitals[1].citiesServed[2] = cover3[2];
        } else if (hospitalNum == 3) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover2[0];
            allHospitals[1].citiesServed[1] = cover2[1];
            allHospitals[1].citiesServed[2] = cover2[2];
            allHospitals[2].citiesServed[0] = cover4[0];
            allHospitals[2].citiesServed[1] = cover4[1];
            allHospitals[2].citiesServed[2] = cover4[2];
        }
    } else if (turn == 3) {
        if (hospitalNum == 1) {
            allHospitals[0].citiesServed[0] = cover3[0];
            allHospitals[0].citiesServed[1] = cover3[1];
            allHospitals[0].citiesServed[2] = cover3[2];
        } else if (hospitalNum == 2) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover4[0];
            allHospitals[1].citiesServed[1] = cover4[1];
            allHospitals[1].citiesServed[2] = cover4[2];
        } else if (hospitalNum == 3) {
            allHospitals[0].citiesServed[0] = cover1[0];
            allHospitals[0].citiesServed[1] = cover1[1];
            allHospitals[0].citiesServed[2] = cover1[2];
            allHospitals[1].citiesServed[0] = cover3[0];
            allHospitals[1].citiesServed[1] = cover3[1];
            allHospitals[1].citiesServed[2] = cover3[2];
            allHospitals[2].citiesServed[0] = cover4[0];
            allHospitals[2].citiesServed[1] = cover4[1];
            allHospitals[2].citiesServed[2] = cover4[2];
        }
    } else if (turn == 4) {
        if (hospitalNum == 1) {
            allHospitals[0].citiesServed[0] = cover4[0];
            allHospitals[0].citiesServed[1] = cover4[1];
            allHospitals[0].citiesServed[2] = cover4[2];
        } else if (hospitalNum == 2) {
            allHospitals[0].citiesServed[0] = cover2[0];
            allHospitals[0].citiesServed[1] = cover2[1];
            allHospitals[0].citiesServed[2] = cover2[2];
            allHospitals[1].citiesServed[0] = cover3[0];
            allHospitals[1].citiesServed[1] = cover3[1];
            allHospitals[1].citiesServed[2] = cover3[2];
        } else if (hospitalNum == 3) {
            allHospitals[0].citiesServed[0] = cover2[0];
            allHospitals[0].citiesServed[1] = cover2[1];
            allHospitals[0].citiesServed[2] = cover2[2];
            allHospitals[1].citiesServed[0] = cover3[0];
            allHospitals[1].citiesServed[1] = cover3[1];
            allHospitals[1].citiesServed[2] = cover3[2];
            allHospitals[2].citiesServed[0] = cover4[0];
            allHospitals[2].citiesServed[1] = cover4[1];
            allHospitals[2].citiesServed[2] = cover4[2];
        }
    } else if (turn == 5) {
        allHospitals[0].citiesServed[0] = cover2[0];
        allHospitals[0].citiesServed[1] = cover2[1];
        allHospitals[0].citiesServed[2] = cover2[2];
        allHospitals[1].citiesServed[0] = cover4[0];
        allHospitals[1].citiesServed[1] = cover4[1];
        allHospitals[1].citiesServed[2] = cover4[2];
    } else if (turn == 6) {
        allHospitals[0].citiesServed[0] = cover3[0];
        allHospitals[0].citiesServed[1] = cover3[1];
        allHospitals[0].citiesServed[2] = cover3[2];
        allHospitals[1].citiesServed[0] = cover4[0];
        allHospitals[1].citiesServed[1] = cover4[1];
        allHospitals[1].citiesServed[2] = cover4[2];
    }
		/* storing covered cities into an array*/
    	check[0] = allHospitals[0].citiesServed[0];
        check[1] = allHospitals[0].citiesServed[1];
        check[2] = allHospitals[0].citiesServed[2];
        check[3] = allHospitals[1].citiesServed[0];
        check[4] = allHospitals[1].citiesServed[1];
        check[5] = allHospitals[1].citiesServed[2];
        check[6] = allHospitals[2].citiesServed[0];
        check[7] = allHospitals[2].citiesServed[1];
        check[8] = allHospitals[2].citiesServed[2];
        check[9] = allHospitals[3].citiesServed[0];
        check[10] = allHospitals[3].citiesServed[1];
        check[11] = allHospitals[3].citiesServed[2];
    	check[12] = '\0';
    	
    	/* the part that check whether all cities are covered or not*/
    	if(strstr(check,cities[0]) != NULL)
    		counter++;
    	if(strstr(check,cities[1]) != NULL) 
    		counter++;
    	if(strstr(check,cities[2]) != NULL) 
    		counter++;
    	if(strstr(check,cities[3]) != NULL)
    		counter++;
    	if(strstr(check,cities[4]) != NULL)
    		counter++;	
		if(strstr(check,cities[5]) != NULL)
    		counter++;	
    	if(counter == 6) result = 1;
			
	if(result == 1)	return result;
		
	solution(hospitalNum, allHospitals, turn+1, result);
	
}	
void main(){

	int hospitalNum, i, turn = 1, result = 0;
	struct Hospital allHospitals[4];
	allHospitals[0].name = "Hospital - 1";
	allHospitals[1].name = "Hospital - 2";
	allHospitals[2].name = "Hospital - 3";
	allHospitals[3].name = "Hospital - 4";
	printf("Enter the maximum number of the hospitals that can be constructed:");
	scanf("%d",&hospitalNum);
	if(hospitalNum < 1 || hospitalNum > 4) printf("Number of the hospitals is invalid!\n");
	else{
		result = solution(hospitalNum, allHospitals, turn, result);
		if(result == 1){
		
			printf("\nYes, can offer health caer to all!\n\n");
			for(i=0;i<hospitalNum;i++){
				printf("%s\n",allHospitals[i].name);
				printf("hospital locations: %c%c%c\n",
				allHospitals[i].citiesServed[0],allHospitals[i].citiesServed[1],allHospitals[i].citiesServed[2]);
			}
		}	
		else printf("\nNo, some cities are not covered.\n");
		
	}
}
