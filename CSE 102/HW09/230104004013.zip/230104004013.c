#include <stdio.h>

typedef struct {
	int map[50][50];
	int Width;
	int Height;
	int Flower_X[10];
	int Flower_Y[10];
}Forest;

typedef struct {
	int Coord_X;
	int Coord_Y;
	int Number_of_Bottle;
}Botanist;

void init_game(Forest *forest, Botanist *botanist){	
	FILE* initial;
	char character;
	int flag = 0, i = 0,j = 0, flower_counter = 0;
	
	initial = fopen("init.txt","r");	
	while(!feof(initial)){
		/* reading initial values  */
		if(flag == 0){
			fscanf(initial,"%d,%d",&forest->Height,&forest->Width);
			fscanf(initial,"%d,%d,%d",&botanist->Coord_Y,&botanist->Coord_X,&botanist->Number_of_Bottle);
			flag = 1;
		}	
		/* reading '\n' character */
		else if(flag == 1){ 
			fscanf(initial,"%c",&character); 
			flag = 2;
		}	
		/* reading map */
		else if(flag == 2){	
			fscanf(initial,"%c",&character);
			if(character == ' '){
			 	forest->map[i][j] = 0;	
			 	j++;
			}
			else if(character == 'T'){
				forest->map[i][j] = 1;	
				j++;	
			}
			else if(character == 'B'){
				forest->map[i][j] = 2;	
				j++;
			}	
			else if(character == 'X'){
				forest->Flower_X[flower_counter] = j;
				forest->Flower_Y[flower_counter] = i;
				flower_counter++;
				forest->map[i][j] = 3;	
				j++;
			}
			else if(character == ','){
				forest->map[i][j] = 4;
				j++;
			}
			else if(character == '\n'){
				i++;
				j=0;	
			}	
			/*
			' ' = 0
			'T' = 1
			'B' = 2
			'X' = 3
			',' = 4
			other = 9
			*/
		}			
	}
	fclose(initial);
}

void display_forest(Forest *forest, Botanist *botanist, int* collected_flower){	
	int i, j;
	for(i=1;i<4*forest->Width;i++) printf("-");
	printf("\n");
	for(i=0;i<forest->Height;i++){
		for(j=0;j<forest->Width;j++)printf(" ");
		for(j=0;j<2*forest->Width;j++){	
			if(forest->map[i][j] == 0){
			 	printf(" ");
			}
			else if(forest->map[i][j] == 1){
				printf("T");		
			}
			else if(forest->map[i][j] == 2){
				printf("B");		
			}
			else if(forest->map[i][j] == 3){
				printf("X");		
			}
			else if(forest->map[i][j] == 4){
				printf(",");		
			}
			/*
			' ' = 0
			'T' = 1
			'B' = 2
			'X' = 3
			',' = 4
			other = 9
			*/
		}
		printf("\n"); 
	}
	for(i=1;i<4*forest->Width;i++) printf("-");
	printf("\n");
	printf("Botanist coordinates: (%d,%d)\n",botanist->Coord_X/2,botanist->Coord_Y);
	printf("Number of collected flowers: %d\n",*collected_flower);
	printf("Number of empty bottle: %d\n",botanist->Number_of_Bottle);
	
	
}

void search(Forest *forest, Botanist *botanist, int* collected_flower){
	char move;
	int i, counter = 0, flag = 0;
	printf("Select Your Move (l(left), r(right), u(up), d(down), e(exit)): ");
	scanf(" %c",&move);
	switch(move){
	/* It is checked whether the movement is possible according to the value chosen by the user.
	Since the values ​​corresponding to the commas are kept on the x-axis of the map array,
	the increase and decrease operations are performed two by two, not one by one */
		case 'l':
		case 'L':
		if(botanist->Coord_X > 1 && forest->map[botanist->Coord_Y][botanist->Coord_X-2] != 1){ 
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 0;
			botanist->Coord_X -= 2;
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 2;
		}
		else{
			printf("You Cannot move in this direction\n");
		}
			break;
		case 'r':
		case 'R':
		if(botanist->Coord_X < 2*(forest->Width-1) && forest->map[botanist->Coord_Y][botanist->Coord_X+2] != 1){ 
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 0;
			botanist->Coord_X += 2;
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 2;
		}
		else{
			printf("You Cannot move in this direction\n");
		}
			break;
		case 'u':
		case 'U':
		if(botanist->Coord_Y > 0 && forest->map[botanist->Coord_Y-1][botanist->Coord_X] != 1){ 
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 0;
			botanist->Coord_Y--;
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 2;
		}
		else{
			printf("You Cannot move in this direction\n");
		}
			break;
		case 'd':
		case 'D':
		if(botanist->Coord_Y < forest->Height-1 && forest->map[botanist->Coord_Y+1][botanist->Coord_X] != 1){ 
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 0;
			botanist->Coord_Y++;
			forest->map[botanist->Coord_Y][botanist->Coord_X] = 2;
		}
		else{
			printf("You Cannot move in this direction\n");
		}
			break;
		case 'e':
		case 'E':
			return;
			break;
		default:
			printf("Invalid Character!\n");
	}
	for(i=0;i<10;i++){
	/* If the botanist collects a flower, the coordinates of the flower are deleted from the flower array,
	 the counter is incremented and the flag variable indicating the presence of a flower is set equal to 1 */
		if(botanist->Coord_X == forest->Flower_X[i] && botanist->Coord_Y == forest->Flower_Y[i]){
			forest->Flower_X[i] = -1;
			forest->Flower_Y[i] = -1;
			(*collected_flower)++;
			botanist->Number_of_Bottle--;
			flag = 1;
		}
	}	
	/* the part that checks whether all the flowers are collected or not if all the flowers collected, counter value will be 10  */
	for(i=0;i<10;i++){
		if(forest->Flower_X[i] == -1 && forest->Flower_Y[i] == -1) counter++;
	}
	display_forest(forest,botanist,collected_flower);
	/* if flag value is equal to 1, it prints a message*/
	if(flag == 1){
		printf("\nBotanist: I've found it\n");
		flag = 0;
	}	 
	/* if counter value is equal to 10, it returns to the main function*/
	if(counter == 10){
		printf("Congratulations, You Win!\n");
		return;
	}
	search(forest,botanist,collected_flower);	
}

void save(Forest forest, Botanist botanist){
	FILE* last;
	int i, j;
	/* saving last values and map in same format as initial.txt file*/
	last = fopen("last.txt","w");
	fprintf(last,"%d,%d\n",forest.Height,forest.Width);
	fprintf(last,"%d,%d,%d\n",botanist.Coord_Y,botanist.Coord_X,botanist.Number_of_Bottle);
	for(i=0;i<forest.Height;i++){
		for(j=0;j<2*forest.Width;j++){	
			if(forest.map[i][j] == 0){
			 	fprintf(last," ");
			}
			else if(forest.map[i][j] == 1){
				fprintf(last,"T");		
			}
			else if(forest.map[i][j] == 2){
				fprintf(last,"B");		
			}
			else if(forest.map[i][j] == 3){
				fprintf(last,"X");		
			}
			else if(forest.map[i][j] == 4){
				fprintf(last,",");		
			}
			/*
			' ' = 0
			'T' = 1
			'B' = 2
			'X' = 3
			',' = 4
			other = 9
			*/
		}
		fprintf(last,"\n"); 
	}
	fclose(last);
}

void main(){
	int i, j, collected_flower = 0;
	Forest forest;
	Botanist botanist;
	/* assigning array elements (some initial numbers) */
	for(i=0;i<50;i++){
		for(j=0;j<50;j++){
			forest.map[i][j] = 9;
		}
	}
	for(i=0;i<10;i++){
		forest.Flower_X[i] = -1;
		forest.Flower_Y[i] = -1;
	}
	/* calling functions */
	init_game(&forest,&botanist);
	display_forest(&forest,&botanist,&collected_flower);
	search(&forest,&botanist,&collected_flower);
	save(forest,botanist);
}
