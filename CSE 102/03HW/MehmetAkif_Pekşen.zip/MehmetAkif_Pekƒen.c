#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int ects = 0, finish = 0, counter = 0, random_num;
int min_height, max_height, min_width, max_width, position_x = 8, position_y = 8;
char direction;
int credit_1_condition[8], credit_2_condition[24];
int credit1_1x, credit1_1y, credit1_2x, credit1_2y, credit1_3x, credit1_3y, credit1_4x, credit1_4y;
int credit2_1x, credit2_1y, credit2_2x, credit2_2y, credit2_3x, credit2_3y;
int i, j, check1_1, check1_2, check1_3, check1_4, check2_1, check2_2, check2_3;

void initialize_game(){
	
	if(position_x == credit1_1x && position_y == credit1_1y && credit_1_condition[check1_1] == 1){
		ects += 8;
		credit_1_condition[check1_1] = 0;
	}
	else if(position_x == credit1_2x && position_y == credit1_2y && credit_1_condition[check1_2] == 1){
		ects += 8;
		credit_1_condition[check1_2] = 0;
	}
	else if(position_x == credit1_3x && position_y == credit1_3y && credit_1_condition[check1_3] == 1){
		ects += 8;
		credit_1_condition[check1_3] = 0;
	}
	else if(position_x == credit1_4x && position_y == credit1_4y && credit_1_condition[check1_4] == 1){
		ects += 8;
		credit_1_condition[check1_4] = 0;
	}
	else if(position_x == credit2_1x && position_y == credit2_1y && credit_2_condition[check2_1] == 1){
		ects += 8;
		credit_2_condition[check2_1] = 0;
	}
	else if(position_x == credit2_2x && position_y == credit2_2y && credit_2_condition[check2_2] == 1){
		ects += 8;
		credit_2_condition[check2_2] = 0;
	}
	else if(position_x == credit2_3x && position_y == credit2_3y && credit_2_condition[check2_3] == 1){
		ects += 8;
		credit_2_condition[check2_3] = 0;
	}
	else if(position_x == 15 && position_y == 15){
		finish = 1;
	}	
	
	
	
	if(ects < 32){
		min_height = 7;
		max_height = 9;
		min_width = 7;
		max_width = 9;
	}
	else if(ects >= 32 && ects < 56){
		min_height = 5;
		max_height = 11;
		min_width = 5;
		max_width = 11;
	}
	else if(ects == 56){
		min_height = 0;
		max_height = 15;
		min_width = 0;
		max_width = 15;
	
	}


}

void print_board(){

	printf("Use W (Up), A (Left), S (D), D (Right) to move\n");		

	for(j=0;j<16;j++){		
		for(i=0;i<16;i++){
			if(i == position_x && j == position_y)
			printf("P ");
			else if(i==15 && j!=15)
			printf(".");
			else if(((j==4 || j==12 ) && (i>=4 && i<=12)) || ((j>4 && j<12) && (i==4 || i==12)) )
			printf("# ");
			else if((j==6 || j==10) && (i>=6 && i<=10) || ((j>6 && j<10) && (i==6 || i==10)))
			printf("# ");
			else if(credit_1_condition[check1_1]==1 && i == credit1_1x && j == credit1_1y)
			printf("1 ");
			else if(credit_1_condition[check1_2]==1 && i == credit1_2x && j == credit1_2y)
			printf("1 ");
			else if(credit_1_condition[check1_3]==1 && i == credit1_3x && j == credit1_3y)
			printf("1 ");
			else if(credit_1_condition[check1_4]==1 && i == credit1_4x && j == credit1_4y)
			printf("1 ");
			else if(credit_2_condition[check2_1]==1 && i == credit2_1x && j == credit2_1y)
			printf("2 ");
			else if(credit_2_condition[check2_2]==1 && i == credit2_2x && j == credit2_2y)
			printf("2 ");
			else if(credit_2_condition[check2_3]==1 && i == credit2_3x && j == credit2_3y)
			printf("2 ");
			else if(j==15 && i==15)
			printf("X");
			else
			printf(". ");
		}
		printf("\n");	
	}
	
	printf("Total ECTS: %d\n",ects);	
	

}

void move_player(char direction){
	switch(direction){
			
		case 'w':
		case 'W': 
		if(position_y > min_height)
		position_y--; 
		else printf("Border! you can't move!\n");
		break;						 	
		
		case 'a':
		case 'A': 
		if(position_x > min_width)
		position_x--;	 
		else printf("Border! you can't move!\n"); 
		break;	

		case 's': 
		case 'S':
		if(position_y < max_height)
		position_y++; 
		else printf("Border! you can't move!\n");
        break;	
		
		case 'd':
		case 'D': 
		if(position_x < max_width)
		position_x++; 
		else printf("Border! you can't move!\n");
		break;
		
		default: printf("\nEnter a valid Value !!\n");
	
	}

}

int main(){
	
	for(i=0;i<8;i++){
	credit_1_condition[i] = 0;
	}

	for(i=0;i<24;i++){
	credit_2_condition[i] = 0;
	}

	srand(time(NULL));
	while(counter != 4){
		random_num = rand();
		if(credit_1_condition[random_num%7]==0 && (random_num%7) != check1_1 && (random_num%7) != check1_2 && (random_num%7) != check1_3){
			credit_1_condition[random_num%7] = 1;
			counter++;	
		switch(counter){
			case 1: for(i=0;i<8;i++){
					
					if(credit_1_condition[i]==1){
						switch(i){							
							case 0: credit1_1x = 7; credit1_1y = 7; break;
							case 1: credit1_1x = 7; credit1_1y = 8; break;
							case 2: credit1_1x = 7; credit1_1y = 9; break;
							case 3:	credit1_1x = 8;	credit1_1y = 7; break;
							case 4:	credit1_1x = 8; credit1_1y = 9; break;
							case 5:	credit1_1x = 9; credit1_1y = 7; break;
							case 6: credit1_1x = 9; credit1_1y = 8; break;
							case 7:	credit1_1x = 9; credit1_1y = 9; break;														
						}		
						check1_1 = i;							
					}
					}						
						break;
					
			case 2: for(i=0;i<8;i++){
					credit_1_condition[check1_1] = 0;
					if(credit_1_condition[i]==1){
						switch(i){							
							case 0: credit1_2x = 7; credit1_2y = 7; break;
							case 1: credit1_2x = 7; credit1_2y = 8; break;
							case 2: credit1_2x = 7; credit1_2y = 9; break;
							case 3:	credit1_2x = 8;	credit1_2y = 7; break;
							case 4:	credit1_2x = 8; credit1_2y = 9; break;
							case 5:	credit1_2x = 9; credit1_2y = 7; break;
							case 6: credit1_2x = 9; credit1_2y = 8; break;
							case 7:	credit1_2x = 9; credit1_2y = 9; break;														
						}		
						check1_2 = i;						
					}
					}
						break;
					
			case 3: for(i=0;i<8;i++){
					credit_1_condition[check1_2] = 0;
					if(credit_1_condition[i]==1){
						switch(i){							
							case 0: credit1_3x = 7; credit1_3y = 7; break;
							case 1: credit1_3x = 7; credit1_3y = 8; break;
							case 2: credit1_3x = 7; credit1_3y = 9; break;
							case 3:	credit1_3x = 8;	credit1_3y = 7; break;
							case 4:	credit1_3x = 8; credit1_3y = 9; break;
							case 5:	credit1_3x = 9; credit1_3y = 7; break;
							case 6: credit1_3x = 9; credit1_3y = 8; break;
							case 7:	credit1_3x = 9; credit1_3y = 9; break;														
						}		
						check1_3 = i;
						

					}
					}
						break;
			
			case 4: for(i=0;i<8;i++){
					credit_1_condition[check1_3] = 0;
					if(credit_1_condition[i]==1){
						switch(i){							
							case 0: credit1_4x = 7; credit1_4y = 7; break;
							case 1: credit1_4x = 7; credit1_4y = 8; break;
							case 2: credit1_4x = 7; credit1_4y = 9; break;
							case 3:	credit1_4x = 8;	credit1_4y = 7; break;
							case 4:	credit1_4x = 8; credit1_4y = 9; break;
							case 5:	credit1_4x = 9; credit1_4y = 7; break;
							case 6: credit1_4x = 9; credit1_4y = 8; break;
							case 7:	credit1_4x = 9; credit1_4y = 9; break;														
						}	
						check1_4 = i;
					}
					}
						break;
			}	
		}
		
	}
	credit_1_condition[check1_1] = 1;
	credit_1_condition[check1_2] = 1;
	credit_1_condition[check1_3] = 1;
	credit_1_condition[check1_4] = 1;
	

	counter = 0;
	while(counter != 3){
		random_num = rand();
		if(credit_2_condition[random_num%23]==0 && (random_num%23) != check2_1 && (random_num%23) != check2_2){
			credit_2_condition[random_num%23] = 1;
			counter++;	
		switch(counter){
			case 1: for(i=0;i<23;i++){
					
					if(credit_2_condition[i]==1){
						switch(i){							
							case 0: credit2_1x = 5; credit2_1y = 5;    break;
							case 1: credit2_1x = 5; credit2_1y = 6;    break;
							case 2: credit2_1x = 5; credit2_1y = 7;    break;
							case 3:	credit2_1x = 5; credit2_1y = 8;    break;
							case 4:	credit2_1x = 5; credit2_1y = 9;    break;
							case 5:	credit2_1x = 5; credit2_1y = 10;   break;
							case 6: credit2_1x = 5; credit2_1y = 11;   break;
							case 7:	credit2_1x = 6; credit2_1y = 5;    break;	
							case 8: credit2_1x = 6; credit2_1y = 11;   break;
							case 9: credit2_1x = 7; credit2_1y = 5;    break;
							case 10: credit2_1x = 7; credit2_1y = 11;  break;
							case 11: credit2_1x = 8; credit2_1y = 5;   break;
							case 12: credit2_1x = 8; credit2_1y = 11;  break;
							case 13: credit2_1x = 9; credit2_1y = 5;   break;
							case 14: credit2_1x = 9; credit2_1y = 11;  break;
							case 15: credit2_1x = 10; credit2_1y = 5;  break;
							case 16: credit2_1x = 10; credit2_1y = 11; break;
							case 17: credit2_1x = 11; credit2_1y = 5;  break;
							case 18: credit2_1x = 11; credit2_1y = 6;  break;
							case 19: credit2_1x = 11; credit2_1y = 7;  break;
							case 20: credit2_1x = 11; credit2_1y = 8;  break;
							case 21: credit2_1x = 11; credit2_1y = 9;  break;
							case 22: credit2_1x = 11; credit2_1y = 10; break;
							case 23: credit2_1x = 11; credit2_1y = 11; break;													
						}		
						check2_1 = i;							
					}
					}						
						break;
					
			case 2: for(i=0;i<23;i++){
					credit_2_condition[check2_1] = 0;
					if(credit_2_condition[i]==1){
						switch(i){							
							case 0: credit2_2x = 5; credit2_2y = 5;    break;
							case 1: credit2_2x = 5; credit2_2y = 6;    break;
							case 2: credit2_2x = 5; credit2_2y = 7;    break;
							case 3:	credit2_2x = 5; credit2_2y = 8;    break;
							case 4:	credit2_2x = 5; credit2_2y = 9;    break;
							case 5:	credit2_2x = 5; credit2_2y = 10;   break;
							case 6: credit2_2x = 5; credit2_2y = 11;   break;
							case 7:	credit2_2x = 6; credit2_2y = 5;    break;	
							case 8: credit2_2x = 6; credit2_2y = 11;   break;
							case 9: credit2_2x = 7; credit2_2y = 5;    break;
							case 10: credit2_2x = 7; credit2_2y = 11;  break;
							case 11: credit2_2x = 8; credit2_2y = 5;   break;
							case 12: credit2_2x = 8; credit2_2y = 11;  break;
							case 13: credit2_2x = 9; credit2_2y = 5;   break;
							case 14: credit2_2x = 9; credit2_2y = 11;  break;
							case 15: credit2_2x = 10; credit2_2y = 5;  break;
							case 16: credit2_2x = 10; credit2_2y = 11; break;
							case 17: credit2_2x = 11; credit2_2y = 5;  break;
							case 18: credit2_2x = 11; credit2_2y = 6;  break;
							case 19: credit2_2x = 11; credit2_2y = 7;  break;
							case 20: credit2_2x = 11; credit2_2y = 8;  break;
							case 21: credit2_2x = 11; credit2_2y = 9;  break;
							case 22: credit2_2x = 11; credit2_2y = 10; break;
							case 23: credit2_2x = 11; credit2_2y = 11; break;														
						}		
						check2_2 = i;						
					}
					}
						break;
					
			case 3: for(i=0;i<23;i++){
					credit_2_condition[check2_2] = 0;
					if(credit_2_condition[i]==1){
						switch(i){							
							case 0: credit2_3x = 5; credit2_3y = 5;    break;
							case 1: credit2_3x = 5; credit2_3y = 6;    break;
							case 2: credit2_3x = 5; credit2_3y = 7;    break;
							case 3:	credit2_3x = 5; credit2_3y = 8;    break;
							case 4:	credit2_3x = 5; credit2_3y = 9;    break;
							case 5:	credit2_3x = 5; credit2_3y = 10;   break;
							case 6: credit2_3x = 5; credit2_3y = 11;   break;
							case 7:	credit2_3x = 6; credit2_3y = 5;    break;	
							case 8: credit2_3x = 6; credit2_3y = 11;   break;
							case 9: credit2_3x = 7; credit2_3y = 5;    break;
							case 10: credit2_3x = 7; credit2_3y = 11;  break;
							case 11: credit2_3x = 8; credit2_3y = 5;   break;
							case 12: credit2_3x = 8; credit2_3y = 11;  break;
							case 13: credit2_3x = 9; credit2_3y = 5;   break;
							case 14: credit2_3x = 9; credit2_3y = 11;  break;
							case 15: credit2_3x = 10; credit2_3y = 5;  break;
							case 16: credit2_3x = 10; credit2_3y = 11; break;
							case 17: credit2_3x = 11; credit2_3y = 5;  break;
							case 18: credit2_3x = 11; credit2_3y = 6;  break;
							case 19: credit2_3x = 11; credit2_3y = 7;  break;
							case 20: credit2_3x = 11; credit2_3y = 8;  break;
							case 21: credit2_3x = 11; credit2_3y = 9;  break;
							case 22: credit2_3x = 11; credit2_3y = 10; break;
							case 23: credit2_3x = 11; credit2_3y = 11; break;													
						}		
						check2_3 = i;	
					}
					}
						break;
			}
		}
	}
	credit_2_condition[check2_1] = 1;
	credit_2_condition[check2_2] = 1;
	credit_2_condition[check2_3] = 1;
	
	while(finish != 1){
	initialize_game();
	print_board();
	if(finish != 1){
	printf("Selcet your move:");
	scanf(" %c",&direction);
	move_player(direction);	
	}	}	
	printf("Congratulations!\n");

return 0;

}





















